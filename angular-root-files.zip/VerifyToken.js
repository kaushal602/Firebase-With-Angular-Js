var admin = require("firebase-admin");

var serviceAccount = require("./ServiceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://workbudi-adverts.firebaseio.com"
});
 const uid = 'some-uid';
 admin.auth().createCustomToken(uid)
 .then((customToken) => {
    console.log(customToken);
 })
 .catch((error)=>{
     console.log(error);
 })
// var firebase = require('firebase');
// require('firebase/auth');
// require('firebase/database');
// firebase.initializeApp({
//     apiKey: "AIzaSyAveOH6FJNmOfawneIfeZXe3LJ5pKX-mwQ",
//     authDomain: "workbudi-adverts.firebaseapp.com",
//     databaseURL: "https://workbudi-adverts.firebaseio.com",
//     projectId: "workbudi-adverts",
//     storageBucket: "workbudi-adverts.appspot.com",
//     messagingSenderId: "824980695375"
// });


// function verifyToken(req, res, next) {
//     firebase.auth().signInWithEmailAndPassword('vishu.developer@gmail.com', 'Admin@428').then((user) => {
//       var user = firebase.auth().currentUser;
//       req.user = user;
//       next();
//     }).catch(function(error) {
      
//     });
// }

// module.exports = verifyToken;