var express = require('express');
var path = require('path');
app = express();
var nodemailer = require('nodemailer');
var EventEmitter = require('events').EventEmitter;
var emitter = new EventEmitter;
var stripe = require("stripe")("sk_test_L5mKhy2QtZYpRo7EZrsVIDGK");
const endpointSecret = 'whsec_9ELBLMhRTYB94PXyRcbf9XEOoSqrUKmP';
const bodyParser = require('body-parser');

var request = require('superagent');
var mailchimpInstance   = 'us15';
var listUniqueId        = '0c8f7dcf41';
var mailchimpApiKey     = 'f284402242a8c2f780596006a46ebbd8-us15';

var googleMapsClient = require('@google/maps').createClient({
  key: process.env.GOOGLE_API_KEY
});

var firebase = require('firebase');
require('firebase/auth');
require('firebase/database');
firebase.initializeApp({
    //databaseURL: 'https://*****.firebaseio.com',
    apiKey: "AIzaSyAveOH6FJNmOfawneIfeZXe3LJ5pKX-mwQ",
    authDomain: "workbudi-adverts.firebaseapp.com",
    databaseURL: "https://workbudi-adverts.firebaseio.com",
    projectId: "workbudi-adverts",
    storageBucket: "workbudi-adverts.appspot.com",
    messagingSenderId: "824980695375"
});
const jwt = require('express-jwt');
const jwks = require('jwks-rsa');
var admin = require("firebase-admin");
var serviceAccount = require("./ServiceAccountKey.json");
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://workbudi-adverts.firebaseio.com"
});
const uid = 'some-uid';
var db = admin.database();
var defaultAuth = admin.auth();
// var admin = require("firebase-admin");

// var serviceAccount = require("path/to/serviceAccountKey.json");

// admin.initializeApp({
//   credential: admin.credential.cert(serviceAccount),
//   databaseURL: "https://workbudi-adverts.firebaseio.com"
// });
//var VerifyToken = require('./VerifyToken');
//fggf
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}) );

app.use(express.static(__dirname + "/dist"));

var port = process.env.PORT || 5000;
app.listen(port);
app.get('/*', function(req, res) {
	res.sendFile(path.join(__dirname + '/dist/index.html'));
})

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
	res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});	

app.post('/payment', function (req, res) {
  //req.body.text = `${req.body.text} from Nodejs`;
  var cid = `${req.body.CouponId}`;
  var cusid = `${req.body.customerid}`;
  if(cusid == ''){
		stripe.customers.create({
		  	email: `${req.body.text}`,
		  	source: `${req.body.id}`,
		}, function (error, customer){
		  	console.log(error);
		  	console.log(customer);
		  	if(error){
		  		res.send(error);
		  	} else {
		  		//res.send(customer);
		  		if(cid != 'NoCouponId'){
			  		stripe.subscriptions.create({
					  customer: customer.id,
					  tax_percent: `${req.body.Taxes}`,
					  coupon: `${req.body.CouponId}`,
					  items: [
					  	{
					  		plan: `${req.body.plan}`,
			      			quantity: `${req.body.NoStore}`,
			      		},
			      	],
					}, function (err, subscription){
						if(err){
                            stripe.customers.retrieve(
                                customer.id,
                                function(err, customer) {
                                    if(err){
                                        console.log('retirve fail');
                                        console.log(err);
                                        //res.send(err)
                                    }
                                    if(customer){
                                        stripe.customers.deleteCard(
                                        customer.id,
                                        customer.default_source,
                                        function(err, card) {
                                            if(err){
                                                console.log('update error');
                                                console.log(err);
                                                    //res.send(err)
                                                }
                                                if(card){
                                                    //res.send(card)
                                                }
                                            }
                                        );
                                    }
                                }
                            );
							res.send(err)
						} else {
							res.send(subscription)
						}
					});
				} else {
					stripe.subscriptions.create({
					  customer: customer.id,
					  tax_percent: `${req.body.Taxes}`,
					  items: [
					  	{
					  		plan: `${req.body.plan}`,
			      			quantity: `${req.body.NoStore}`,
			      		},
			      	],
					}, function (err, subscription){
						if(err){
                            stripe.customers.retrieve(
                                customer.id,
                                function(err, customer) {
                                    if(err){
                                        console.log('retirve fail');
                                        console.log(err);
                                        //res.send(err)
                                    }
                                    if(customer){
                                        stripe.customers.deleteCard(
                                        customer.id,
                                        customer.default_source,
                                        function(err, card) {
                                            if(err){
                                                console.log('update error');
                                                console.log(err);
                                                    //res.send(err)
                                                }
                                                if(card){
                                                    //res.send(card)
                                                }
                                            }
                                        );
                                    }
                                }
                            );
							res.send(err)
						} else {
							res.send(subscription)
						}
					});
				}
		  	}
	    });
	} else {
		stripe.customers.createSource(
		  	`${req.body.customerid}`,
		  	{ source: `${req.body.id}` },
		  	function(err, card) {
		  		if(err){
                    console.log('CreateSourceFail');
                    console.log(err);
		  		} else {
		  			if(cid != 'NoCouponId'){
				  		stripe.subscriptions.create({
						  customer: cusid,
						  tax_percent: `${req.body.Taxes}`,
						  coupon: `${req.body.CouponId}`,
						  items: [
						  	{
						  		plan: `${req.body.plan}`,
				      			quantity: `${req.body.NoStore}`,
				      		},
				      	],
						}, function (err, subscription){
							if(err){
                                stripe.customers.retrieve(
                                    `${req.body.customerid}`,
                                    function(err, customer) {
                                        if(err){
                                            console.log('retirve fail');
                                            console.log(err);
                                        }
                                        if(customer){
                                            stripe.customers.deleteCard(
                                                cusid,
                                                customer.default_source,
                                                function(err, card) {
                                                    if(err){
                                                        console.log('update error');
                                                        console.log(err);
                                                    }
                                                    if(card){
                                                    }
                                                }
                                            );
                                        }
                                    }
                                );
								res.send(err)
							} else {
                                res.send(subscription)
                                stripe.customers.retrieve(
                                    `${req.body.customerid}`,
                                    function(err, customer) {
                                        if(err){
                                            res.send(err)
                                        }
                                        if(customer){
                                            stripe.customers.updateCard(
                                            cusid,
                                            customer.default_source,
                                          function(err, card) {
                                              if(err){
                                                    //res.send(err)
                                                }
                                                if(card){
                                                    //res.send(card)
                                                }
                                            }
                                          );
                                        }
                                    }
                                );
							}
						});
					} else {
						stripe.subscriptions.create({
						  	customer: cusid,
						  	tax_percent: `${req.body.Taxes}`,
						  	items: [
							  	{
							  		plan: `${req.body.plan}`,
					      			quantity: `${req.body.NoStore}`,
					      		},
					      	],
						}, function (err, subscription){
							if(err){
                                console.log('Create Cus Fail');
                                console.log(err);
                                stripe.customers.retrieve(
                                    `${req.body.customerid}`,
                                    function(err, customer) {
                                        if(err){
                                            console.log('retirve fail');
                                            console.log(err);
                                            //res.send(err)
                                        }
                                        if(customer){
                                            stripe.customers.deleteCard(
                                            cusid,
                                            customer.default_source,
                                            function(err, card) {
                                                if(err){
                                                    console.log('update error');
                                                    console.log(err);
                                                        //res.send(err)
                                                    }
                                                    if(card){
                                                        //res.send(card)
                                                    }
                                                }
                                            );
                                        }
                                    }
                                );
								res.send(err)
							} else {
								res.send(subscription)
								stripe.customers.retrieve(
								  `${req.body.customerid}`,
								  function(err, customer) {
								  	if(err){
                                          console.log('retirve fail');
                                          console.log(err);
								  		res.send(err)
								  	}
								  	if(customer){
								  		stripe.customers.updateCard(
										  cusid,
										  customer.default_source,
										function(err, card) {
										    if(err){
                                                console.log('update error');
                                                console.log(err);
										  		//res.send(err)
										  	}
										  	if(card){
										  		//res.send(card)
										  	}
										  }
										);
								  	}
								  }
								);
							}
						});
					}
		  		}
		    	// asynchronously called
		  	}
		);
	}
});

app.post('/couponlist', function (req, res) {
	//res.send('test response');
	stripe.coupons.list({ 
		limit: 50 
	},function(err, coupons) {
    	if(err){
			res.send(err)
		}
		if(coupons) {
			res.send(coupons)
		}
	});
});
// stripe.customers.retrieve(
//     subscription.customer,
//        function(err, customer) {
//             if(err){
//                 res.send(err)
//             }
//             if(customer){
//                 stripe.customers.deleteCard(
//                     customer.id,
//                     customer.default_source,
//                   function(err, confirmation) {
//                       if(err){
//                           //res.send(err)
//                       } else {
//                           // asynchronously called
//                           //res.send(confirmation)
//                       }
//                   }
//               );
//                 //res.send(subscription)''
//             }
//       }
//   );
app.post('/updatecard', function (req, res) {
	stripe.customers.retrieve(
	  `${req.body.customerid}`,
	  function(err, customer) {
	  	if(err){
	  		res.send(err)
	  	}
	  	if(customer){
            stripe.customers.deleteCard(
                `${req.body.customerid}`,
                customer.default_source,
                function(err, confirmation) {
                    if(err){
                        res.send(err)
                    } else {
                        stripe.customers.createSource(
                            `${req.body.customerid}`,
                            { source: `${req.body.tokenid}` },
                            function(err, card) {
                                if(err){
                                    //res.send(err)
                                } else {
                                    stripe.customers.retrieve(
                                        `${req.body.customerid}`,
                                        function(err, customer) {
                                            if(err){
                                                res.send(err)
                                            }
                                            if(customer){
                                                stripe.customers.updateCard(
                                                customer.id,
                                                customer.default_source,
                                              function(err, card) {
                                                  if(err){
                                                        res.send(err)
                                                    }
                                                    if(card){
                                                        res.send(card)
                                                    }
                                                }
                                              );
                                            }
                                        }
                                    );
                                }
                                // asynchronously called
                            }
                        );
                        // asynchronously called
                        //res.send(confirmation)
                    }
                }
            );
	  		// stripe.customers.updateCard(
			//   customer.id,
			//   customer.default_source,
			//   { exp_month: `${req.body.exp_month}`, exp_year:`${req.body.exp_year}`, name:`${req.body.cardname}`,address_city: `${req.body.address_city}`, address_country:`${req.body.address_country}`, address_line1:`${req.body.address_line1}`, address_zip:`${req.body.address_zip}`, address_state:`${req.body.address_state}` },
			//   function(err, card) {
			//     if(err){
			//   		res.send(err)
			//   	}
			//   	if(card){
			//   		res.send(card)
			//   	}
			//   }
			// );
	  	}
	  }
	);
})

app.post('/deletecard', function (req, res) {
	stripe.customers.retrieve(
	  `${req.body.customerid}`,
	  function(err, customer) {
	  	if(err){
	  		res.send(err)
	  	}
	  	if(customer){
	  		stripe.customers.deleteCard(
			  customer.id,
			  customer.default_source,
			  function(err, confirmation) {
			    if(err){
			  		res.send(err)
			  	}
			  	if(card){
			  		res.send(confirmation)
			  	}
			  }
			);
	  	}
	  }
	);
})

app.post('/customerdelete', function (req, res) {
	stripe.customers.del(
       	`${req.body.id}`,
    function (err, confirmation){
		if(err){
			res.send(err)
		} 
		if(confirmation){
			res.send(confirmation)
		}
  	});
})
/*var db1 = firebase.database().ref(`/payments/${req.body.id}`);
	db1.on("value", function(snapshot) {
			Sub = snapshot.val();
			res.send(Sub)
    }, function (errorObject) {
    	res.send(errorObject)
      console.log("The read failed: " + errorObject.code);
    });*/
/*this.db.object(`/payments/${req.body.id}`).valueChanges().subscribe(res => {
		if(res1.key != null){
			stripe.customers.del(
		       	res.customer,
		    function (err, confirmation){
				if(err){
					res.send(err)
				} else {
					res.send(confirmation)
				}
		  	});
		} else {
			res.send('ok');
		}
	});*/
	
app.post('/subdelete', function (req, res) {
  stripe.subscriptions.del(`${req.body.id}`, {
  	 at_period_end: false,
  },function (err, subscription){
	if(err){
		res.send(err)
	} else {
		res.send(subscription)
	}
  	//res.send(error)
  });
})

app.post('/canclenow', function (req, res) {
  stripe.subscriptions.del(`${req.body.id}`, {
  	 at_period_end: false,
  },function (err, subscription){
	if(err){
		res.send(err)
	} else {
		stripe.customers.retrieve(
		  subscription.customer,
			 function(err, customer) {
			  	if(err){
			  		res.send(err)
			  	}
			  	if(customer){
			  		stripe.customers.deleteCard(
					  	customer.id,
			  			customer.default_source,
						function(err, confirmation) {
							if(err){
								//res.send(err)
							} else {
						    	// asynchronously called
						    	//res.send(confirmation)
							}
						}
					);
			  		//res.send(subscription)''
			  	}
			}
		);
		res.send(subscription)
	}
  	//res.send(error)
  });
})
app.post('/cancleend', function (req, res) {
  stripe.subscriptions.del(`${req.body.id}`, {
  	 at_period_end: true,
  },function (err, subscription){
	if(err){
		res.send(err)
	} else {
		stripe.customers.retrieve(
		  subscription.customer,
			 function(err, customer) {
			  	if(err){
			  		res.send(err)
			  	}
			  	if(customer){
			  		stripe.customers.deleteCard(
					  	customer.id,
			  			customer.default_source,
						function(err, confirmation) {
							if(err){
								//res.send(err)
							} else {
						    	// asynchronously called
						    	//res.send(confirmation)
							}
						}
					);
			  		//res.send(subscription)''
			  	}
			}
		);
		res.send(subscription)
	}
  	//res.send(error)
  });
})

app.post('/upcominginvoice', function (req, res) {
	stripe.subscriptions.retrieve(
	  `${req.body.subid}`,
	  function(error, subscription) {
	    if(error){
			res.send(error)
		} else {
			stripe.invoices.retrieveUpcoming(`${req.body.id}`,{
			  	subscription: `${req.body.subid}`,
			  	//subscription_prorate: true,
			  	subscription_proration_date: `${req.body.proration_date}`,
			  	subscription_tax_percent: `${req.body.tax}`,
			  	subscription_items: [{ 
			  		//id: subscription.items.data[0].id,
			  		id: subscription.items.data[0].id,
			  		plan: `${req.body.PlanIds}`,
			  		quantity: `${req.body.quantity}`,
			  	}],
		  	},function (err, upcoming){
					if(err){
						res.send(err)
					} else {
						res.send(upcoming)
					}
			  	//res.send(error)
			  	}
			);
			//res.send(subscription)
			/*stripe.subscriptions.update(`${req.body.subid}`, {
				cancel_at_period_end: false,
				items: [{
						id: subscription.items.data[0].id,
					    plan: `${req.body.plan}`,
					    quantity: `${req.body.NoStore}`,
				  	}],
			}, function (err, subscription){
				if(err){
					res.send(err)
				} else {
					res.send(subscription)
				}
			  	//res.send(error)
			});*/
		}
	  }
	);
  	
})

app.post('/subUpdate', function (req, res) {
	//customer = stripe.customers.retrieve(`${req.body.SubCus}`);
	//res.send(subscription)
	stripe.subscriptions.retrieve(
	  `${req.body.subid}`,
	  function(err, subscription) {
	    if(err){
			res.send(err)
		} else {
			//res.send(subscription)
			stripe.subscriptions.update(`${req.body.subid}`, {
				cancel_at_period_end: false,
				items: [{
						id: subscription.items.data[0].id,
					    plan: `${req.body.plan}`,
					    quantity: `${req.body.NoStore}`,
				  	}],
			}, function (err, subscription){
				if(err){
					res.send(err)
				} else {
					res.send(subscription)
				}
			  	//res.send(error)
			});
		}
	  }
	);
	
})

app.post('/subscribUpdate', function (req, res) {
	stripe.subscriptions.retrieve(
	  `${req.body.subid}`,
	  function(err, subscription) {
	    if(err){
			res.send(err)
		} else {
			//res.send(subscription)
			var prorate = `${req.body.prorate}`;
			if(prorate != 'true'){
				stripe.subscriptions.update(`${req.body.subid}`, {
					cancel_at_period_end: false,
  					prorate: false,
					tax_percent: `${req.body.tax_percent}`,
					items: [{
							id: subscription.items.data[0].id,
						    quantity: `${req.body.NoStore}`,
					  	}],
				}, function (err, subscription){
					if(err){
						res.send(err)
					} else {
						res.send(subscription)
					}
				  	
				});
			} else {
				stripe.subscriptions.update(`${req.body.subid}`, {
					cancel_at_period_end: false,
					tax_percent: `${req.body.tax_percent}`,
					proration_date: `${req.body.proration_date}`,
					prorate: true,
					items: [{
							id: subscription.items.data[0].id,
						    quantity: `${req.body.NoStore}`,
					  	}],
				}, function (err, subscription){
					if(err){
						res.send(err)
					} else {
						res.send(subscription)
					}
				});
			}
		}
	  }
	);
})

app.post('/subscription', function (req, res) {
    request
        .post('https://' + mailchimpInstance + '.api.mailchimp.com/3.0/lists/' + listUniqueId + '/members/')
        .set('Content-Type', 'application/json;charset=utf-8')
        .set('Authorization', 'Basic ' + new Buffer('any:' + mailchimpApiKey ).toString('base64'))
        .send({
          'email_address': `${req.body.email}`,
          'status': 'subscribed',
        })
        .end(function(err, response) {
          if (err) {
          	//response.status < 300 || (response.status === 400 && response.body.title === "Member Exists")
            res.send(err);
          } else {
            res.send(response);
          }
      });
});


app.post('/getaddress', function (req, res) {
	var API_KEY = "AIzaSyCtyVAj1YsM2q4kKG7YVTuOp0wsNSZDjc4";
    var BASE_URL = "https://maps.googleapis.com/maps/api/geocode/json?address=";

    var address = `${req.body.text}`;

    var url = BASE_URL + address + "&key=" + API_KEY;

    request(url, function (error, response, body) {
        if (!error) {
            res.json(response);
        } else {
            res.send(error)
        }
    });
});
app.post('/updategetaddress', function (req, res) {
	var API_KEY = "AIzaSyCtyVAj1YsM2q4kKG7YVTuOp0wsNSZDjc4";
    var BASE_URL = "https://maps.googleapis.com/maps/api/geocode/json?address=";

    var address = `${req.body.text}`;

    var url = BASE_URL + address + "&key=" + API_KEY;

    request(url, function (error, response, body) {
        if (!error) {
            res.json(response);
        } else {
            res.send(error)
        }
    });
});
app.post('/getaddressname', function (req, res) {
	var API_KEY = process.env.GOOGLE_API_KEY;
    var BASE_URL = "https://maps.googleapis.com/maps/api/geocode/json?";
    var latitude = `${req.body.latitude}`;
    var longitude = `${req.body.longitude}`;
    var url = BASE_URL + "latlng=" +latitude+','+longitude+  "&sensor=true&key=" + API_KEY;

    request(url, function (error, response, body) {
        if (!error) {
            res.json(response);
        } else {
            res.send(error)
        }
    });
});

app.post('/sendemail', function (req, res) {
	var transporter = nodemailer.createTransport({
	  	service: 'smtp',
	  	host: "smtp.gmail.com",
    	port: 587,
    	secure: false,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_USER_PASS
        }
	});

	var mailOptions = {
	  from: 'test1.igex@gmail.com',
	  to: `${req.body.to}`,
	  subject: 'Stripe Subscription',
	  html: '<div class="db-EmailReceiptPreview" style="position: relative;height: 420px;overflow: hidden;width: 600px;border-radius: 4px;background-color: #fff;color: #fff;"><div class="db-EmailReceiptPreview-border" style="bottom: 0;left: 0;position: absolute;right: 0;top: 0;border-radius: 4px;box-shadow: inset 0 0 0 1px rgba(0,0,0,.1);pointer-events: none;"></div><div class="db-EmailReceiptPreview-banner" style="background-color: rgb(244, 143, 68);display: table-cell;width: 600px;vertical-align: bottom;"><div class="db-EmailReceiptPreview-bannerLeft" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Left.png)!important;background-position: 100% 100%!important;">&nbsp;</div><div class="db-EmailReceiptPreview-bannerIcon" style=" display: table-cell;width: 96px;height: 156px;vertical-align: bottom;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Icon--empty.png)!important;background-position: bottom!important;background-size: 100% 100%;"><div class="db-EmailReceiptPreview-merchantIcon" style="background-color: rgb(244, 143, 68);display: block;height: 70px;margin: 0 auto 24px;width: 70px;border-radius: 50%;border: 3px solid #fff;"><img class="db-EmailReceiptPreview-merchantIconImg" src="https://nodestripepayment.herokuapp.com/assets/wb-logo.png" height="156" width="96" style="height: 64px;width: 64px;"></div></div><div class="db-EmailReceiptPreview-bannerRight" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Right.png)!important;background-position: 0 100%!important;">&nbsp;</div></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 22px;line-height: 22px;text-align: center;"><span>Workbudi Subscription Notification</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Hi, '+req.body.Name+'</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Your '+req.body.PlanName+' Subscription Successfully Created.</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Total Store: '+req.body.TotalStore+'</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Amount Paid: £'+req.body.amount.toFixed(2)+'</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Tax Percent: '+req.body.tax_percent+' %</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Date Paid: '+req.body.PaymentDate+'</span></div></div>'
	};

	transporter.sendMail(mailOptions, function(error, info){
	  if (error) {
	  	res.send(error)
	  } 
	  if(info){
	  	res.send(info)
	    //console.log('Email sent: ' + info.response);
	  }
	}); 
});

app.post('/updatecardemail', function (req, res) {
	var transporter = nodemailer.createTransport({
	  	service: 'smtp',
	  	host: "smtp.gmail.com",
    	port: 587,
    	secure: false,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_USER_PASS
        }
	});

	var mailOptions = {
	  from: 'hello@workbuddy.com',
	  to: `${req.body.to}`,
	  subject: 'Stripe Subscription',
	  html: '<div class="db-EmailReceiptPreview" style="position: relative;height: 420px;overflow: hidden;width: 600px;border-radius: 4px;background-color: #fff;color: #fff;"><div class="db-EmailReceiptPreview-border" style="bottom: 0;left: 0;position: absolute;right: 0;top: 0;border-radius: 4px;box-shadow: inset 0 0 0 1px rgba(0,0,0,.1);pointer-events: none;"></div><div class="db-EmailReceiptPreview-banner" style="background-color: rgb(244, 143, 68);display: table-cell;width: 600px;vertical-align: bottom;"><div class="db-EmailReceiptPreview-bannerLeft" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Left.png)!important;background-position: 100% 100%!important;">&nbsp;</div><div class="db-EmailReceiptPreview-bannerIcon" style=" display: table-cell;width: 96px;height: 156px;vertical-align: bottom;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Icon--empty.png)!important;background-position: bottom!important;background-size: 100% 100%;"><div class="db-EmailReceiptPreview-merchantIcon" style="background-color: rgb(244, 143, 68);display: block;height: 70px;margin: 0 auto 24px;width: 70px;border-radius: 50%;border: 3px solid #fff;"><img class="db-EmailReceiptPreview-merchantIconImg" src="https://nodestripepayment.herokuapp.com/assets/wb-logo.png" height="156" width="96" style="height: 64px;width: 64px;"></div></div><div class="db-EmailReceiptPreview-bannerRight" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Right.png)!important;background-position: 0 100%!important;">&nbsp;</div></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 22px;line-height: 22px;text-align: center;"><span>Workbudi Subscription Notification</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Hi, '+req.body.Name+'</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Your Card Details Updated Successfully.</span></div></div>'
	};

	transporter.sendMail(mailOptions, function(error, info){
	  if (error) {
	  	res.send(error)
	  } 
	  if(info){
	  	res.send(info)
	    //console.log('Email sent: ' + info.response);
	  }
	}); 
});

app.post('/deleteemail', function (req, res) {
	var transporter = nodemailer.createTransport({
	  	service: 'smtp',
	  	host: "smtp.gmail.com",
    	port: 587,
    	secure: false,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_USER_PASS
        }
	});

	var mailOptions = {
	  from: 'hello@workbuddy.com',
	  to: `${req.body.to}`,
	  subject: 'Stripe Subscription',
	  html: '<div class="db-EmailReceiptPreview" style="position: relative;height: 420px;overflow: hidden;width: 600px;border-radius: 4px;background-color: #fff;color: #fff;"><div class="db-EmailReceiptPreview-border" style="bottom: 0;left: 0;position: absolute;right: 0;top: 0;border-radius: 4px;box-shadow: inset 0 0 0 1px rgba(0,0,0,.1);pointer-events: none;"></div><div class="db-EmailReceiptPreview-banner" style="background-color: rgb(244, 143, 68);display: table-cell;width: 600px;vertical-align: bottom;"><div class="db-EmailReceiptPreview-bannerLeft" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Left.png)!important;background-position: 100% 100%!important;">&nbsp;</div><div class="db-EmailReceiptPreview-bannerIcon" style=" display: table-cell;width: 96px;height: 156px;vertical-align: bottom;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Icon--empty.png)!important;background-position: bottom!important;background-size: 100% 100%;"><div class="db-EmailReceiptPreview-merchantIcon" style="background-color: rgb(244, 143, 68);display: block;height: 70px;margin: 0 auto 24px;width: 70px;border-radius: 50%;border: 3px solid #fff;"><img class="db-EmailReceiptPreview-merchantIconImg" src="https://nodestripepayment.herokuapp.com/assets/wb-logo.png" height="156" width="96" style="height: 64px;width: 64px;"></div></div><div class="db-EmailReceiptPreview-bannerRight" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Right.png)!important;background-position: 0 100%!important;">&nbsp;</div></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 22px;line-height: 22px;text-align: center;"><span>Workbudi Subscription Notification</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Hi, '+req.body.Name+'</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Your subscription has been deleted successfully.</span></div></div>'
	};

	transporter.sendMail(mailOptions, function(error, info){
	  if (error) {
	  	res.send(error)
	  } 
	  if(info){
	  	res.send(info)
	    //console.log('Email sent: ' + info.response);
	  }
	}); 
});

app.post('/canclenowemail', function (req, res) {
	var transporter = nodemailer.createTransport({
	  	service: 'smtp',
	  	host: "smtp.gmail.com",
    	port: 587,
    	secure: false,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_USER_PASS
        }
	});

	var mailOptions = {
	  from: 'hello@workbuddy.com',
	  to: `${req.body.to}`,
	  subject: 'Stripe Subscription',
	  html: '<div class="db-EmailReceiptPreview" style="position: relative;height: 420px;overflow: hidden;width: 600px;border-radius: 4px;background-color: #fff;color: #fff;"><div class="db-EmailReceiptPreview-border" style="bottom: 0;left: 0;position: absolute;right: 0;top: 0;border-radius: 4px;box-shadow: inset 0 0 0 1px rgba(0,0,0,.1);pointer-events: none;"></div><div class="db-EmailReceiptPreview-banner" style="background-color: rgb(244, 143, 68);display: table-cell;width: 600px;vertical-align: bottom;"><div class="db-EmailReceiptPreview-bannerLeft" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Left.png)!important;background-position: 100% 100%!important;">&nbsp;</div><div class="db-EmailReceiptPreview-bannerIcon" style=" display: table-cell;width: 96px;height: 156px;vertical-align: bottom;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Icon--empty.png)!important;background-position: bottom!important;background-size: 100% 100%;"><div class="db-EmailReceiptPreview-merchantIcon" style="background-color: rgb(244, 143, 68);display: block;height: 70px;margin: 0 auto 24px;width: 70px;border-radius: 50%;border: 3px solid #fff;"><img class="db-EmailReceiptPreview-merchantIconImg" src="https://nodestripepayment.herokuapp.com/assets/wb-logo.png" height="156" width="96" style="height: 64px;width: 64px;"></div></div><div class="db-EmailReceiptPreview-bannerRight" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Right.png)!important;background-position: 0 100%!important;">&nbsp;</div></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 22px;line-height: 22px;text-align: center;"><span>Workbudi Subscription Notification</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Hi, '+req.body.Name+'</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Your subscription has been canceled successfully.</span></div></div>'
	};

	transporter.sendMail(mailOptions, function(error, info){
	  if (error) {
	  	res.send(error)
	  } 
	  if(info){
	  	res.send(info)
	    //console.log('Email sent: ' + info.response);
	  }
	}); 
});

app.post('/cancleend', function (req, res) {
	var transporter = nodemailer.createTransport({
	  	service: 'smtp',
	  	host: "smtp.gmail.com",
    	port: 587,
    	secure: false,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_USER_PASS
        }
	});

	var mailOptions = {
	  from: 'hello@workbuddy.com',
	  to: `${req.body.to}`,
	  subject: 'Stripe Subscription',
	  html: '<div class="db-EmailReceiptPreview" style="position: relative;height: 420px;overflow: hidden;width: 600px;border-radius: 4px;background-color: #fff;color: #fff;"><div class="db-EmailReceiptPreview-border" style="bottom: 0;left: 0;position: absolute;right: 0;top: 0;border-radius: 4px;box-shadow: inset 0 0 0 1px rgba(0,0,0,.1);pointer-events: none;"></div><div class="db-EmailReceiptPreview-banner" style="background-color: rgb(244, 143, 68);display: table-cell;width: 600px;vertical-align: bottom;"><div class="db-EmailReceiptPreview-bannerLeft" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Left.png)!important;background-position: 100% 100%!important;">&nbsp;</div><div class="db-EmailReceiptPreview-bannerIcon" style=" display: table-cell;width: 96px;height: 156px;vertical-align: bottom;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Icon--empty.png)!important;background-position: bottom!important;background-size: 100% 100%;"><div class="db-EmailReceiptPreview-merchantIcon" style="background-color: rgb(244, 143, 68);display: block;height: 70px;margin: 0 auto 24px;width: 70px;border-radius: 50%;border: 3px solid #fff;"><img class="db-EmailReceiptPreview-merchantIconImg" src="https://nodestripepayment.herokuapp.com/assets/wb-logo.png" height="156" width="96" style="height: 64px;width: 64px;"></div></div><div class="db-EmailReceiptPreview-bannerRight" style="display: table-cell;width: 252px;height: 156px;vertical-align: bottom;background-size: 100% 100%;background-image: url(https://stripe-images.s3.amazonaws.com/notifications/hosted/20180110/Header/Right.png)!important;background-position: 0 100%!important;">&nbsp;</div></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 22px;line-height: 22px;text-align: center;"><span>Workbudi Subscription Notification</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Hi, '+req.body.Name+'</span></div><div class="db-EmailReceiptPreview-intro" style="margin-top: -8px;padding: 0 0 8px;color: #32325d;font-size: 16px;line-height: 22px;text-align: left;"><span>Your subscription plan cancel End of the Pariod.</span></div></div>'
	};

	transporter.sendMail(mailOptions, function(error, info){
	  if (error) {
	  	res.send(error)
	  } 
	  if(info){
	  	res.send(info)
	  }
	}); 
});

app.post('/stripe-webhook', function(request, response,next){
	
    admin.auth().createCustomToken(uid)
    .then((customToken) => {
        firebase.auth().signInWithCustomToken(customToken)
        .then(function(user_login){
            if (request.body.type === 'customer.subscription.created') {
                console.log(request.body.data.object);
                emitter.emit('chargeSucceeded', request.body.data.object);

                var ref = db.ref('payments');
                ref.orderByChild('customer').equalTo(request.body.data.object.customer).once("value", function(snapshot) {
                    snapshot.forEach(function(child) { 
                        db.ref('/payments/'+child.key).update({
                            "canceled_at": request.body.data.object.canceled_at,
                            "created": request.body.data.object.created,
                            "current_period_end": request.body.data.object.current_period_end,
                            "current_period_start": request.body.data.object.current_period_start,
                        });
                    }); 
                });
            }
            if (request.body.type === 'customer.subscription.deleted') {
                console.log(request.body.data.object);
                emitter.emit('chargeSucceeded', request.body.data.object);
                var ref = db.ref('payments');
                ref.orderByChild('customer').equalTo(request.body.data.object.customer).once("value", function(snapshot) {
                    snapshot.forEach(function(child) { 
                        db.ref('/payments/'+child.key).update({
                            "canceled_at": request.body.data.object.canceled_at,
                            "created": request.body.data.object.created,
                            "current_period_end": request.body.data.object.current_period_end,
                            "current_period_start": request.body.data.object.current_period_start,
                            "status": request.body.data.object.status,
                            "eventtype":'cancelnow',
                        });
                        var usrid = child.key;
                        var ref = db.ref('/store/'+usrid);
                        ref.once('value',function(snap) {
                            var data = [];
                            var sub = [];
                            snap.forEach(ss => {
                                data.push(ss.child('StorKey').val());
                                sub.push(ss.child('sub').val());
                            });
                            for (i=0; i < data.length; i++) {
                                if(sub[i]!=0){
                                    db.ref('/store/'+usrid+'/'+data[i]).update({
                                        "subscriptions": 'inactive',
                                        "sub":0,
                                    });
                                    //db.ref('/store/'+usrid+'/'+data[i]).remove();
                                    //db.ref('/advertising/'+usrid+'/'+data[i]).remove();
                                }
                            }   
                        });
                    }); 
                });
                stripe.customers.retrieve(
                    request.body.data.object.customer,
                    function(err, customer) {
                        if(err){
                            res.send(err)
                        }
                        if(customer){
                            stripe.customers.deleteCard(
                                customer.id,
                                customer.default_source,
                                function(err, confirmation) {
                                    if(err){
                                        //res.send(err)
                                    } else {
                                        //res.send(confirmation)
                                    }
                                }
                            );
                        }
                    }
                );
            }
            if (request.body.type === 'customer.subscription.updated') {
                //console.log(request.body.data.object);
                emitter.emit('chargeSucceeded', request.body.data.object);
                var ref = db.ref('payments');
                ref.orderByChild('customer').equalTo(request.body.data.object.customer).once("value", function(snapshot) {
                    snapshot.forEach(function(child) {
                        
                        if(request.body.data.object.quantity>request.body.data.previous_attributes.quantity){
                            stripe.invoices.create({
                                customer: request.body.data.object.customer,
                                auto_advance: false,
                                tax_percent: request.body.data.object.tax_percent,
                            },function(err, invoice) {
                                if(invoice){
                                    stripe.invoices.pay(invoice['id'], function(err, invoice) {
                                    });
                                }
                            });
                        } else {
                            db.ref('/payments/'+child.key).update({
                                "canceled_at": request.body.data.object.canceled_at,
                                "created": request.body.data.object.created,
                                "current_period_end": request.body.data.object.current_period_end,
                                "current_period_start": request.body.data.object.current_period_start,
                                "status": request.body.data.object.status,
                                "quantity":request.body.data.object.quantity,
                            });
                            var usrid = child.key;
                            var ref = db.ref('/store/'+usrid);
                            ref.orderByChild('PaymentFail').equalTo('No').once("value", function(snapshot) {
                                snapshot.forEach(function(child) {
                                    var storid = child.key;
                                    var keys = snapshot.key;
                                    db.ref('/store/'+usrid+'/'+storid).update({
                                        "subscriptions": 'active',
                                        "sub":1,
                                    });
                                });
                            });
                            // var data = [];
                            // var sub = [];
                            // ref.once('value',function(snap) {
                            //     snap.forEach(ss => {
                            //         data.push(ss.child('StorKey').val());
                            //         sub.push(ss.child('sub').val());
                            //     });
                            //     for (i=0; i < data.length; i++) {
                            //         if(sub[i]!=1){
                            //             db.ref('/store/'+child.key+'/'+data[i]).update({
                            //                 "subscriptions": 'active',
                            //                 "sub":1,
                            //             });
                            //         }
                            //     }
                            // });
                            var ref1 = db.ref('/store/'+usrid);
                            ref1.orderByChild('isdeleted').equalTo('deleted').once("value", function(snapshot) {
                                snapshot.forEach(function(child) {
                                    var storid = child.key;
                                    var keys = snapshot.key;
                                    db.ref('/store/'+usrid+'/'+storid).remove();
                                    db.ref('/locations/'+storid).remove();
                                    db.ref('/advertising/'+usrid+'/'+storid).remove();
                                });
                            });
                        }
                    }); 
                });
            }
            if (request.body.type === 'invoice.payment_succeeded') {
                //console.log(request.body.data.object);
                emitter.emit('chargeSucceeded', request.body.data.object);
                var ref = db.ref('payments');
                ref.orderByChild('customer').equalTo(request.body.data.object.customer).once("value", function(snapshot) {
                    snapshot.forEach(function(child) { 
                        for(var j=0; j<request.body.data.object.lines.data.length; j++){
                            db.ref('/payments/'+child.key).update({
                                "status": 'active',
                                "quantity":request.body.data.object.lines.data[j].quantity,
                            });
                        }
                        var data = [];
                        var sub1 = [];
                        var ref = db.ref('/store/'+child.key);
                        ref.once('value',function(snap) {
                            snap.forEach(ss => {
                                data.push(ss.child('StorKey').val());
                                sub1.push(ss.child('sub').val());
                            });
                            for (i=0; i < data.length; i++) {
                                if(sub1[i]!=1){
                                    db.ref('/store/'+child.key+'/'+data[i]).update({
                                        "subscriptions": 'active',
                                        "sub":1,
                                    });
                                }
                            } 
                        });
                        var usrid = child.key;
                        var ref1 = db.ref('/store/'+usrid);
                        ref1.orderByChild('isdeleted').equalTo('deleted').once("value", function(snapshot) {
                            snapshot.forEach(function(child) {
                                var storid = child.key;
                                var keys = snapshot.key;
                                db.ref('/store/'+usrid+'/'+storid).remove();
                                db.ref('/locations/'+storid).remove();
                                db.ref('/advertising/'+usrid+'/'+storid).remove();
                            });
                        });
                    }); 
                });
            }
            if (request.body.type === 'invoice.payment_failed') {
                //console.log(request.body.data.object);
                emitter.emit('chargeSucceeded', request.body.data.object);
                console.log(request.body.data.object.id);
                console.log(request.body.data.object.paid);
                var InvoiceId = request.body.data.object.id;
                console.log(InvoiceId);
                console.log(request.body.data.object.lines.data[1].proration);
                if(request.body.data.object.lines.data[1].proration == true){
                    stripe.invoices.voidInvoice(InvoiceId, function(err, invoice) {
                        if (err)
                        {
                            console.log(err);
                        }
                        else{
                            console.log(invoice);
                        }
                        // asynchronously called
                    });
                }
                // var ref = db.ref('payments');
                // ref.orderByChild('customer').equalTo(request.body.data.object.customer).once("value", function(snapshot) {
                //     snapshot.forEach(function(child) {
                //         var userid = child.key;
                //         var ref1 = db.ref('/store/'+userid);
                //         ref1.orderByChild('PaymentFail').equalTo('No').once("value", function(snapshot) {
                //             snapshot.forEach(function(child) {
                //                 var storid = child.key;
                //                 var keys = snapshot.key;
                //                 db.ref('/store/'+userid+'/'+storid).update({
                //                     "PaymentFail": 'Yes',
                //                 });
                //             });
                //         });
                //     });
                // });
            }
            if (request.body.type === 'charge.failed') {
				//var stripe = require("stripe")("sk_test_L5mKhy2QtZYpRo7EZrsVIDGK");
				//const endpointSecret = 'whsec_9ELBLMhRTYB94PXyRcbf9XEOoSqrUKmP';
                console.log(request.body.data.object);
				emitter.emit('chargeSucceeded', request.body.data.object);
				console.log("Charge failed");
                //console.log(request.body.data.object.invoice);
				// var InvoiceId = request.body.data.object.invoice;
				//  console.log(InvoiceId);
                //  stripe.invoices.voidInvoice(InvoiceId, function(err, invoice) {
				// 	 if (err)
				// 	 {
				// 		 console.log(err);
				// 	 }
				// 	 else{
				// 		 console.log(invoice);
				// 	 }
                //      // asynchronously called
                //  });

                var ref = db.ref('payments');
                ref.orderByChild('customer').equalTo(request.body.data.object.customer).once("value", function(snapshot) {
                    snapshot.forEach(function(child) {
                        var userid = child.key;
                        var ref1 = db.ref('/store/'+userid);
                        ref1.orderByChild('PaymentFail').equalTo('No').once("value", function(snapshot) {
                            snapshot.forEach(function(child) {
                                var storid = child.key;
                                var keys = snapshot.key;
                                db.ref('/store/'+userid+'/'+storid).update({
                                    "PaymentFail": 'Yes',
                                });
                            });
                        });
                        var ref = db.ref('/payments/'+userid);
                        ref.once('value',function(snap) {
                            //console.log(snap.val());
                            var json = snap.val();
                            var abc = JSON.stringify(json);
                            var obj = JSON.parse(abc);
                            //console.log(obj.quantity);
                            stripe.subscriptions.retrieve(
                                obj.id,
                                function(err, subscription) {
                                    if(err){
                                        //res.send(err)
                                    } else {
                                        stripe.subscriptions.update(obj.id, {
                                            cancel_at_period_end: false,
                                            prorate: false,
                                            items: [{
                                                id: subscription.items.data[0].id,
                                                quantity: obj.quantity,
                                            }],
                                        }, function (err, subscription){
                                            if(err){
                                                //res.send(err)
                                                //console.log(err);
                                                console.log('fail err');
                                            } else {
                                                //console.log(subscription);
                                                console.log('fail sub');
                                                //res.send(subscription)
                                            }
                                        });
                                    }
                                }
                            );
                            
                        });
                    }); 
                });
            }
            if (request.body.type === 'invoice.finalized') {
                console.log(request.body.data.object);
                emitter.emit('chargeSucceeded', request.body.data.object);
                console.log('finalized Invoice');
                console.log(request.body.data.object.id);
                // if(request.body.data.object.paid==false){
                //     stripe.invoices.voidInvoice(
                //         "in_1Db2g2Jqb8v17brlyvI3AwIJ",
                //     function(err, invoice) {
                //         // asynchronously called
                //         if(err){
                //             console.log(err);
                //             console.log('finalized err');
                //         } else {
                //             console.log(invoice);
                //             console.log('finalized Suss');
                //         }
                //     });
                // }
            }

        });
        //console.log(customToken);
    })
    .catch((error)=>{
        console.log(error);
    });
	
	response.send('OK');
});

