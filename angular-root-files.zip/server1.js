var express = require('express');
var path = require('path');
app = express();
var stripe = require("stripe")("sk_test_NEmijlVT7jeJD2vWMMLaLj2C");
const bodyParser = require('body-parser');

var request = require('superagent');
var mailchimpInstance   = 'us1';
var listUniqueId        = 'c55a430ddd';
var mailchimpApiKey     = '5adb63f936a2046a0dd5610939b0f324-us1';

var googleMapsClient = require('@google/maps').createClient({
  key: 'AIzaSyCtyVAj1YsM2q4kKG7YVTuOp0wsNSZDjc4'
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}) );

app.use(express.static(__dirname + "/dist"));

var port = process.env.PORT || 5000;
app.listen(port);
app.get('/*', function(req, res) {
	res.sendFile(path.join(__dirname + '/dist/index.html'));
})

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
	res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});	

app.post('/payment', function (req, res) {
  //req.body.text = `${req.body.text} from Nodejs`;
  //res.send(req.body)
  stripe.customers.create({
  	email: `${req.body.text}`,
  	source: `${req.body.id}`,
  }, function (error, customer){
  	console.log(error);
  	console.log(customer);
  	if(error){
  		res.send(error);
  	} else {
  		//res.send(customer);
  		stripe.subscriptions.create({
		  customer: customer.id,
		  //tax_percent: `${req.body.Taxes}`,
		  items: [
		  	{
		  		plan: `${req.body.plan}`,
      			quantity: `${req.body.NoStore}`,
      		},
      	],
		}, function (err, subscription){
			if(err){
				res.send(err)
			} else {
				res.send(subscription)
			}
		});
  	}
  	//res.send(error)
  });
})

app.post('/subdelete', function (req, res) {
  stripe.subscriptions.del(`${req.body.id}`, {
  	 at_period_end: false,
  },function (err, subscription){
	if(err){
		res.send(err)
	} else {
		res.send(subscription)
	}
  	//res.send(error)
  });
})

app.post('/subUpdate', function (req, res) {
	//customer = stripe.customers.retrieve(`${req.body.SubCus}`);
	//var subscription = customer.subscriptions.retrieve(`${req.body.subid}`);
	//res.send(subscription)
	stripe.subscriptions.retrieve(
	  `${req.body.subid}`,
	  function(err, subscription) {
	    if(err){
			res.send(err)
		} else {
			//res.send(subscription)
			stripe.subscriptions.update(`${req.body.subid}`, {
				cancel_at_period_end: false,
				items: [{
						id: subscription.items.data[0].id,
					    plan: `${req.body.plan}`,
					    quantity: `${req.body.NoStore}`,
				  	}],
			}, function (err, subscription){
				if(err){
					res.send(err)
				} else {
					res.send(subscription)
				}
			  	//res.send(error)
			});
		}
	  }
	);
	
})

app.post('/subscription', function (req, res) {
    request
        .post('https://' + mailchimpInstance + '.api.mailchimp.com/3.0/lists/' + listUniqueId + '/members/')
        .set('Content-Type', 'application/json;charset=utf-8')
        .set('Authorization', 'Basic ' + new Buffer('any:' + mailchimpApiKey ).toString('base64'))
        .send({
          'email_address': `${req.body.email}`,
          'status': 'subscribed',
        })
        .end(function(err, response) {
          if (err) {
          	//response.status < 300 || (response.status === 400 && response.body.title === "Member Exists")
            res.send(err);
          } else {
            res.send(response);
          }
      });
});


app.post('/getaddress', function (req, res) {
	var API_KEY = "AIzaSyCtyVAj1YsM2q4kKG7YVTuOp0wsNSZDjc4";
    var BASE_URL = "https://maps.googleapis.com/maps/api/geocode/json?address=";

    var address = `${req.body.text}`;

    var url = BASE_URL + address + "&key=" + API_KEY;

    request(url, function (error, response, body) {
        if (!error) {
            res.json(response);
        } else {
            res.send(error)
        }
    });
	/*googleMapsClient.geocode({
	address: `${req.body.Taxes}`
	}, function(err, response) {
	  if (err) {
	    console.log(err);
	  } else {
	  	console.log(response);
	  }
	});*/
})