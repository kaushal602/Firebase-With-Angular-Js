import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Router } from '@angular/router';
import 'firebase/storage';
import * as firebase from 'firebase/app';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import "rxjs/Rx";

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  constructor( private http: HttpClient) { }
 /* createTodo() {
  	console.log('123');
  var API_URL = 'https://jsonplaceholder.typicode.com/posts/1';
	  return this.http.get(API_URL)
	    .map(response => {
	    	console.log(response);
	      //return new Todo(response.json());
	    });
	}*/

  ngOnInit() {
  	//this.createTodo();
  }

}
