import { Component, OnInit, HostListener, Pipe, PipeTransform } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/first';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import 'firebase/storage';
import * as firebase from 'firebase/app';
//import * as moment from 'moment';
import {BsDatepickerConfig} from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-advertising',
  templateUrl: './advertising.component.html',
  styleUrls: ['./advertising.component.css']
})
@Pipe({
  name: 'orderBy',
  pure: false
})
export class AdvertisingComponent implements OnInit {
	myForm: FormGroup;
	myForm1: FormGroup;
	private isValidFormSubmitted: boolean;
	dropdownList = [];
	dropdown = [];
    selectedItems = [];
    dropdownSettings = {};
    editselectedItems = [];
    uid: string;
	UserStore: string;
	StoreName: string;
	Details: string;
	StartDate: Date;
	EndDate: Date;
	dis:any;
	sdt: any;
	edt: any;
	sid: any;
	fid: any;

	minDate: Date;
	minDate2: Date;
  	maxDate: Date;
  	ErrorMsg: any;
  	ErrorMsg1: any;
	itemName: any;
	offer: any;
    userForm: any;
	myFormUpdate: any;
	authState: any;
	user1: any;
	user2: any;
	user3: any;
	payment: any;
	paymentyes: any;
	nopaymentclass: any;
	result: any[];
	advertising: any[];
	values: any;
	userId: string;
	arrBirds: any[];
	totlstor: any[];
	asdfg: any[];
	qwert: any[];
	zxcvb: any[];
	upstore: any[];
	arrBirds1: any[];
	totlstor1: any[];
	storerror: any;
	storclass: any;
	submsg: any;
	storelenght: number;
	countstore: number;
	subscribmsg: string;

	activstore: any;

  	order: string = 'StartDate';

  	constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router,private fb: FormBuilder) {
	  	this.angularAuth.authState.subscribe((auth) => {
	        this.authState = auth
	        console.log(auth);
	        if(auth) { 
		        this.userId = auth.uid
		    	let dropdownList=[];
		    	let selectedItems=[];
		        this.user1 = this.db.list('/store/'+this.authState.uid).valueChanges();
		            this.user1.subscribe(res => {
		            this.result = res
		            var j = 0;
		            var storarray = Array();
		            res.forEach(function (value) {
					  console.log(value);
					  if(value['subscriptions']=='active'){
					  	storarray.push(value);
					  	console.log(value['subscriptions']);
					  	j++;
					  }
					});
					console.log(storarray);
		            for (var i = 0; i < storarray.length; i++) {
	            		this.dropdownList[i] = {'id':storarray[i].StorKey,'itemName':storarray[i].Name};
		            	this.selectedItems[0] = {'id':storarray[0].StorKey,'itemName':storarray[0].Name};
				    }
		            /*this.storelenght = res.length;
		            for (var i = 0; i < res.length; i++) {
		            	this.dropdownList[i] = {'id':res[i].StorKey,'itemName':res[i].Name};
		            	this.selectedItems[0] = {'id':res[0].StorKey,'itemName':res[0].Name};
				    }*/
			    });
		        this.user2 = this.db.list('/advertising/'+this.authState.uid).snapshotChanges();
		            this.user2.subscribe(res => {
		            this.advertising = res
		            console.log(this.advertising);
		            let arrBirds = [];
		            let totlstor = [];
		            let qwert = [];
		            for (var i = 0; i < res.length; i++) {
		            	var tlt = [i];
		            	 this.user2 = this.db.list('/advertising/'+this.authState.uid+'/'+res[i].key+'/offer').valueChanges();
				            this.user2.subscribe(res => {
				            	console.log(res);
				            	var arrBirds = res
				            	totlstor.push({['name']:res});
					    });
		            }
		            //console.log(totlstor);
		            this.asdfg = totlstor;
		            //this.zxcvb = totlstor;
		            console.log(this.asdfg);
			    });
		        this.user2 = this.db.object('/payments/'+this.authState.uid).valueChanges();
		            this.user2.subscribe(res => {
		            if(res){
			            this.payment = res
			            console.log(res);
			            console.log(res);
			            if(this.payment.status == 'active'){
			            	var countstore = `${this.storelenght}`;
			            	console.log(countstore);
			            	console.log(this.payment.quantity);
			            	if(countstore == this.payment.quantity){
				            	this.nopaymentclass = "yessubs";
				            	this.submsg = 'Yessubmsg';
				            } else {
				            	/*this.nopaymentclass = "nosubs";
			            		this.submsg = 'Nosubmsg';
								this.subscribmsg = 'Please active subscription for all stores';*/
								this.nopaymentclass = "";
			            		this.submsg = '';
								this.subscribmsg = '';
				            }
			            } else {
			            	this.nopaymentclass = "nosubs";
			            	this.submsg = 'Nosubmsg';
			            }
			        }
		            console.log(this.nopaymentclass);
		            //console.log(this.payment[0].plan.nickname);
			    });
		    } else {
		    	this.router.navigate(['/login']);
		    }
		});

		this.minDate = new Date();
	    this.minDate.setDate(this.minDate.getDate());
	    this.minDate2 = new Date();
	    this.minDate2.setDate(this.minDate.getDate() + 1);
  	}
  ngOnInit() {
  	//this.subscribmsg = 'Please create a new subscription to publish messages to your local workbudi community';
  	this.subscribmsg = '';
	//this.modelname = '';
  	this.nopaymentclass = '';
  	this.storclass = "";
	this.dropdownSettings = { 
      //enableCheckAll:true,
      singleSelection: false, 
      text:"Select Store *",
      selectAllText:'Select All',
      unSelectAllText:'UnSelect All',
      enableSearchFilter: true,
      classes:"myclass custom-class",
      badgeShowLimit:2,
    };

    this.myForm = this.fb.group({
        UserStore: new FormControl(null,this.selectedItems),
        //uid: new FormControl('', Validators.required),
	    Details: new FormControl('', Validators.required),
	    StartDate: new FormControl('', Validators.required),
	    EndDate: new FormControl('', Validators.required),
    });

   this.myForm1 = this.fb.group({
        UserStore: [null,this.editselectedItems],
        //uid: [null, Validators.required],
	    Details: [null, Validators.required],
	    sdt: [null, Validators.required],
	    edt: [null, Validators.required],
	    sid: [null, Validators.required],
	    fid: [null],
    });
  }
  	isFieldValid(field: string) {
	    return !this.myForm.get(field).valid && this.myForm.get(field).touched;
	}
	displayFieldCss(field: string) {
	    return {
	      'has-error': this.isFieldValid(field),
	      'has-feedback': this.isFieldValid(field)
	    };
	}
	lastdate: any;
	onSubmit() {
	    //console.log(this.myForm.status);
	    if (this.myForm.valid) {
	      	console.log('form submitted');
	      	//this.uid = this.myForm.get('uid').value;
		   	this.UserStore = this.myForm.get('UserStore').value;
		   	this.Details = this.myForm.get('Details').value;
		   	this.StartDate = this.myForm.get('StartDate').value;
		   	var stdata = this.StartDate;
		   	//console.log(this.StartDate);
		   	this.EndDate = this.myForm.get('EndDate').value;
		   	var endata = this.EndDate;
		   	var offertxt = "";
	   		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	 		for (var i = 0; i < 5; i++)
	    	offertxt += possible.charAt(Math.floor(Math.random() * possible.length));
		   	//this.offer = 'offer-'+offertxt;
		   	console.log(this.UserStore);
		   	if(this.UserStore.length >0) {
			   	for (var i = 0; i < this.UserStore.length; i++) {
			   		var stid = this.UserStore[i]['id'];
			   		var stname = this.UserStore[i]['itemName'];
			   		var allUsers = firebase.database().ref('users/');
      				var db1 = firebase.database().ref(`/advertising/${this.userId}/`+stid+`/offer`);
      				var sdf = this.userId;
      				console.log(sdf);
      				let Sub = [];
			   		db1.on("value", function(snapshot) {
			   			Sub = snapshot.val();
			        }, function (errorObject) {
			          console.log("The read failed: " + errorObject.code);
			        });
			        console.log('12');
			        console.log(Sub);
			        if(Sub == null){
			        	var lenth = 0;
			        } else {
			        	var o = Sub;
						var arr = Object.keys(o).map(function(k) { return o[k] });
						console.log(arr[0].StartDate)
				        console.log(arr.length);
				        var lenth = arr.length;
			        }
			        
			        if(lenth==0){
			        	this.db.object(`/advertising/${this.userId}/`+stid+`/offer/`+offertxt).set({
				   			StoreName: stname,
				   			StoreId: stid,
				   			Details: this.Details,
				   			StartDate: stdata.toISOString(),
				   			EndDate: endata.toISOString(),
				   			OfferId: offertxt,
			      		});
			      		this.ErrorMsg = "";
		            	this.myForm.reset();
			        } else {
			        	//console.log(111111);
			        	var k=0;
			        	for (var j = 0; j < arr.length; j++) {
			   				//console.log('a');
			   				console.log(arr[j].StartDate);
			   				console.log(stdata.toISOString());
			   				console.log(arr[j].EndDate);
			   				console.log(endata.toISOString());
			   				if((arr[j].StartDate <= stdata.toISOString()) && (arr[j].EndDate >= stdata.toISOString())) {
						    	console.log('invalid');
						    	this.ErrorMsg = "Date overlap an existing offer date.";
						    	//console.log('er');
						    	k=1;
						    	break;
						    } else {
						    	console.log('valid');
		            			this.ErrorMsg = "";
		            			this.myForm.reset();
						    }
			   			}
			   			console.log('k='+k);
			   			if(k==0){
			   				this.db.object(`/advertising/${this.userId}/`+stid+`/offer/`+offertxt).set({
					   			StoreName: stname,
					   			StoreId: stid,
					   			Details: this.Details,
					   			StartDate: stdata.toISOString(),
					   			EndDate: endata.toISOString(),
					   			OfferId: offertxt,
				      		});
				      		this.ErrorMsg = "";
		            		this.myForm.reset();
			   			}
			        }
			   	}
			} else {
				this.storerror = "Please Select Store";
            	this.storclass = "vatreq";
			}
		   	//this.myForm.reset();
	    } else {
	    	console.log('form not submitted');
	    	this.ErrorMsg = "Please enter requires fields."
	      	this.validateAllFormFields(this.myForm);
	    }
	}
	
    onUpdateSubmit() {
	     if (this.myForm1.valid) {
	      	//console.log('form submitted');
	      	//this.uid = this.myForm1.get('uid').value;
		   	this.UserStore = this.myForm1.get('UserStore').value;
		   	this.Details = this.myForm1.get('Details').value;
		   	this.StartDate = this.myForm1.get('sdt').value;
		   	var stdata = this.StartDate;
		   	this.EndDate = this.myForm1.get('edt').value;
		   	var endata = this.EndDate;
		   	this.sid = this.myForm1.get('sid').value;
		   	this.fid = this.myForm1.get('fid').value;
		   	var fid = this.fid;
		   	for (var i = 0; i < this.UserStore.length; i++) {
		   		var stid = this.UserStore[i]['id'];
			   	var stname = this.UserStore[i]['itemName'];
		   		var db1 = firebase.database().ref(`/advertising/${this.userId}/`+stid+`/offer`);
  				var sdf = this.userId;
  				console.log(sdf);
  				let Sub = [];
		   		db1.on("value", function(snapshot) {
		   			Sub = snapshot.val();
		        }, function (errorObject) {
		          console.log("The read failed: " + errorObject.code);
		        });
		        if(Sub == null){
		        	var lenth = 0;
		        } else {
		        	var o = Sub;
					var arr = Object.keys(o).map(function(k) { return o[k] });
					console.log(arr[0].StartDate)
			        console.log(arr.length);
			        var lenth = arr.length;
		        }
		        if(lenth>1){
		        	for (var j = 0; j < arr.length; j++) {
            			let newDate = new Date(arr[i].StartDate);
            			console.log(newDate);
            			console.log(arr[i].EndDate);
            			let newDate1 = new Date(arr[i].EndDate);
		        		//if(this.fid != arr[i].OfferId){
		        			console.log(this.fid);
            				console.log(arr[i].OfferId);
            				var l = 0;
            				if((newDate < stdata) || (newDate1 > stdata) && (this.fid != arr[i].OfferId)) {
	            				
					      		l=1;
					      		this.display='none';
					      		//location.reload();
	            			} else {
	            				this.ErrorMsg1 = "Date overlap an existing offer date.";
							    console.log('er');
							    l=0;
	            				console.log(5);
	            			}
	            			if(l==1){
	            				this.db.object(`/advertising/${this.userId}/`+stid+`/offer/`+fid).update({
						   			StoreName: stname,
						   			StoreId: stid,
						   			Details: this.Details,
						   			StartDate: stdata,
						   			EndDate: endata,
						   			OfferId: fid,
					      		});
					      		//location.reload();
	            			}
		        		/*} else {
	            			this.display='none';
					      	location.reload();
	            		}*/  
		        	}
		        } else {
		        	this.db.object(`/advertising/${this.userId}/`+stid+`/offer/`+fid).update({
			   			StoreName: stname,
			   			StoreId: stid,
			   			Details: this.Details,
			   			StartDate: stdata,
			   			EndDate: endata,
			   			OfferId: fid,
		      		});
		      		this.display='none';
		      		//this.router.navigate(['/advertising']);
		        }
		   	}
		   
	    } else {
	    	console.log('form not submitted');
	    	this.ErrorMsg = "Please enter requires fields."
	    }
	}
	deleteadver(){
		//this.uid = this.myForm1.get('uid').value;
		this.sid = this.myForm1.get('sid').value;
		this.fid = this.myForm1.get('fid').value;
		this.db.object(`/advertising/${this.userId}/`+this.sid+`/offer/`+this.fid).remove();
	   this.display='none';
	   this.router.navigate(['/advertising']);
	}
	validateAllFormFields(formGroup: FormGroup) {
	    Object.keys(formGroup.controls).forEach(field => {
	      //console.log(field);
	      const control = formGroup.get(field);
	      if (control instanceof FormControl) {
	        control.markAsTouched({ onlySelf: true });
	      } else if (control instanceof FormGroup) {
	        this.validateAllFormFields(control);
	      }
	    });
	}
  	onItemSelect(item:any){
	    console.log(item);
	    console.log(this.selectedItems);
	}
	OnItemDeSelect(item:any){
	    //console.log(item);
	    //console.log(this.selectedItems);
	}
	onSelectAll(items: any){
	    //console.log(items);
	}
	onDeSelectAll(items: any){
	}

	display='none';
	id:any;
	nam:any;
	offerid:any;
	stor: any;
	stor1: any;
 	openModal(id,nam,offerid){

       this.display='block'; 
  		//alert(id);
  		console.log(id);
  		console.log(offerid);
  		this.editselectedItems = [{'id':id,'itemName':nam}];
  		//let arrBirds1 = [];
        let totlstor1 = [];
        let upstore = [];
        this.stor = this.db.object(`/advertising/${this.userId}/`+id+`/offer/`+offerid).valueChanges();
            this.stor.subscribe(res1 => {
            	//console.log(res1);
            	this.upstore = res1;
            	this.dis=res1.Details;
            	this.edt=res1.EndDate;
            	this.sdt=res1.StartDate;
            	this.sid=res1.StoreId;
            	this.fid=res1.OfferId;
            	console.log(this.upstore);
            	

	    });
        //let asdfg1 = [];
        /*this.db.list(`/advertising/${this.userId}/`+id+`/offer`).once('value').then(function(snapshot) {
		  //var username = (snapshot.val() && snapshot.val().username) || 'Anonymous';
		  console.log(snapshot);
		  // ...
		});*/
  		/*this.user3 = this.db.list(`/advertising/${this.userId}/`+id+`/offer`).snapshotChanges();
            this.user3.subscribe(res => {
            	console.log(res.length);
            	//this.arrBirds1 = res
            	for (var i = 0; i < res.length; i++) {
	            	this.stor = this.db.object(`/advertising/${this.userId}/`+id+`/offer/`+res[i].key).valueChanges();
			            this.stor.subscribe(res1 => {
			            	console.log(res1);
			            	var arrBirds1 = res1
			            	//var arrBirds = res
			            	//totlstor1.push(res);
			            	totlstor1.push(arrBirds1);

				    });
		        }
        		this.upstore = totlstor1;
        		console.log(this.upstore);
				//this.totlstor1.push(res);
				//console.log(this.arrBirds1);
            console.log(res.EndDate);
            this.dis=res.Details;
            this.edt=res.EndDate;
            this.sdt=res.StartDate;
            this.sid=res.StoreId;
            this.editselectedItems = [{'id':id,'itemName':nam}];

	    });*/
        //this.upstore = totlstor1;
	    //console.log(this.upstore);
    }
    onCloseHandled(){
       this.display='none'; 
    }

}
