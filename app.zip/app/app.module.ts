import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
//import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
//import {MultiselectModule} from 'ngx-multiselect';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { routes } from './app.routes';
import { AngularFireModule } from 'angularfire2';
import { environment } from '../environments/environment';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import {enableProdMode} from '@angular/core';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { RegistrationComponent } from './registration/registration.component';
import { SubscriptionsComponent } from './subscriptions/subscriptions.component';
import { PaymentService } from './payments/payment.service';
import { AdvertisingComponent } from './advertising/advertising.component';
import { MysubscriptionsplanComponent } from './mysubscriptionsplan/mysubscriptionsplan.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MobilesidebarComponent } from './mobilesidebar/mobilesidebar.component';
import { AboutusComponent } from './aboutus/aboutus.component';

import { OrderModule } from 'ngx-order-pipe';

import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';

import { AgmCoreModule } from '@agm/core';

import { HttpClientModule } from '@angular/common/http';
import { EditsubscriptionsComponent } from './editsubscriptions/editsubscriptions.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { RecentComponent } from './recent/recent.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { GetpaymentComponent } from './getpayment/getpayment.component';
import { GeoService } from './geo.service';
import { ChangeforgotpasswordComponent } from './changeforgotpassword/changeforgotpassword.component';


enableProdMode();
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ProfileComponent,
    RegistrationComponent,
    SubscriptionsComponent,
    AdvertisingComponent,
    MysubscriptionsplanComponent,
    SidebarComponent,
    MobilesidebarComponent,
    AboutusComponent,
    EditsubscriptionsComponent,
    UserloginComponent,
    RecentComponent,
    UserregistrationComponent,
    ForgotpasswordComponent,
    ChangepasswordComponent,
    GetpaymentComponent,
    ChangeforgotpasswordComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule, 
    ReactiveFormsModule,
    AngularFireModule.initializeApp(environment.firebase),
    //AngularFireModule.initializeApp(environment.firebase2,'secondary'),
    AngularFireAuthModule,
    AngularFireDatabaseModule,
    BsDatepickerModule.forRoot(),
    AngularMultiSelectModule,
    routes,
    CommonModule,
    HttpClientModule,
    RecaptchaModule.forRoot(),
    RecaptchaFormsModule,
    OrderModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCtyVAj1YsM2q4kKG7YVTuOp0wsNSZDjc4'
    })
  ],
  providers: [PaymentService, GeoService],
  bootstrap: [AppComponent],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class AppModule { }
