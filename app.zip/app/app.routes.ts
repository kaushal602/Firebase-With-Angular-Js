import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';
import { RegistrationComponent } from './registration/registration.component';
import { SubscriptionsComponent } from './subscriptions/subscriptions.component';
import { AdvertisingComponent } from './advertising/advertising.component';
import { MysubscriptionsplanComponent } from './mysubscriptionsplan/mysubscriptionsplan.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { EditsubscriptionsComponent } from './editsubscriptions/editsubscriptions.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { RecentComponent } from './recent/recent.component';
import { UserregistrationComponent } from './userregistration/userregistration.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { GetpaymentComponent } from './getpayment/getpayment.component';
import { ChangeforgotpasswordComponent } from './changeforgotpassword/changeforgotpassword.component';

export const router: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent },
    { path: 'profile', component: ProfileComponent },
    { path: 'register', component: RegistrationComponent },
    { path: 'subscriptions', component: SubscriptionsComponent },
    { path: 'mysubscriptionsplan', component: MysubscriptionsplanComponent },
    { path: 'advertising', component: AdvertisingComponent },
    { path: 'about', component: AboutusComponent },
    { path: 'editsubscriptions', component: EditsubscriptionsComponent },
    { path: 'userlogin', component: UserloginComponent },
    { path: 'recent', component: RecentComponent },
    { path: 'userregistration', component: UserregistrationComponent },
    { path: 'forgotpassword', component: ForgotpasswordComponent },
    { path: 'changepassword', component: ChangepasswordComponent },
    { path: 'getpaymentdetail', component: GetpaymentComponent },
    { path: 'change-forgotpassword', component: ChangeforgotpasswordComponent },
]

export const routes: ModuleWithProviders = RouterModule.forRoot(router);