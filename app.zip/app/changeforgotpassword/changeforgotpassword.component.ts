import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import 'firebase/storage';
import * as firebase from 'firebase/app';
import * as Stripe from 'stripe';
import CryptoJS from 'crypto-js';

@Component({
  selector: 'app-changeforgotpassword',
  templateUrl: './changeforgotpassword.component.html',
  styleUrls: ['./changeforgotpassword.component.css']
})
export class ChangeforgotpasswordComponent implements OnInit {

  Password: string;
	ConfirmPassword: string;
	phonenumber: string;
	password1:any;
	//file: any;

	ErrorMsg: any;

	authState: any;
    userId: string;
    code:any;
    mode:any;
    apiKey:any;
    lang:any;
  constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router,private route: ActivatedRoute) {
  	this.angularAuth.authState.subscribe((auth) => {
        this.authState = auth
        if(auth) {
        	this.userId = auth.uid
	    } else {
	    	//this.router.navigate(['/login']);
	    }
    });
    this.route.queryParams.subscribe(params => {
        this.code = params["oobCode"];
        console.log(this.code);
        this.mode = params["mode"];
        console.log(this.mode);
        this.apiKey = params["apiKey"];
        console.log(this.apiKey);
        this.lang = params["lang"];
        console.log(this.lang);

    });
  }

	
	private isValidFormSubmitted: boolean;
	userForm = new FormGroup({
    Password: new FormControl(null, Validators.required),
    ConfirmPassword: new FormControl(null, Validators.required),
	});
    onFormSubmit() {
    	console.log(this.userForm.status)
	   //this.isValidFormSubmitted = false;
	   if(this.userForm.invalid){
	   		this.ErrorMsg = "Please enter requires fields.";
		  //return;	
	   } 
	   if(this.userForm.valid){
		    this.Password = this.userForm.get('Password').value;
            this.ConfirmPassword = this.userForm.get('ConfirmPassword').value;
            console.log(this.Password);
            console.log(this.ConfirmPassword);
            this.ErrorMsg ="";
            if(this.Password.length>=6){
                if(this.Password==this.ConfirmPassword){
                    this.angularAuth.auth.confirmPasswordReset(this.code, this.Password)
                    .then(function() {
                        console.log('Success');
                        window.location.href = "https://nodestripepayment.herokuapp.com/userlogin";
                    })
                    .catch(function(error) {
                        console.log(error);
                        alert('Password reset link expired! Please try again.');
                    })
                } else {
                    this.ErrorMsg = "Password Not Match!";
                }
            } else {
                this.ErrorMsg = "Password should be at least 6 characters";
            }
            
		    // this.angularAuth.auth.signInWithEmailAndPassword(this.Password, this.ConfirmPassword).then((user) => {
			//    	var textString = this.ConfirmPassword; 
			// 	var words = CryptoJS.enc.Utf8.parse(textString); 
			// 	var base64 = CryptoJS.enc.Base64.stringify(words);
			//    	this.password1 = base64;
			//    	this.db.object(`/users/${this.userId}`).update({
			//    		Password: this.password1
			//    	});
		   	// 	//this.ErrorMsg = "Form Submit";
		   	// 	this.router.navigate(['/advertising']);
			// }).catch(function(error) {
			// 	alert(error.message);
			// 	console.log(error);
            // });
            
		   
		}
	}

  ngOnInit() {
  }

}
