import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditsubscriptionsComponent } from './editsubscriptions.component';

describe('EditsubscriptionsComponent', () => {
  let component: EditsubscriptionsComponent;
  let fixture: ComponentFixture<EditsubscriptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditsubscriptionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditsubscriptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
