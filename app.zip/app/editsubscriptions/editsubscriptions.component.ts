import { Component, OnInit, HostListener, AfterViewInit, OnDestroy, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { PaymentService } from '../payments/payment.service';
import { environment } from '../../environments/environment';
import 'firebase/storage';
import * as firebase from 'firebase/app';
import * as Stripe from 'stripe';
import * as GeoFire from "geofire";


@Component({
  selector: 'app-editsubscriptions',
  templateUrl: './editsubscriptions.component.html',
  styleUrls: ['./editsubscriptions.component.css']
})
export class EditsubscriptionsComponent implements OnInit {
//@ViewChild('cardInfo') cardInfo: ElementRef;
	
	userForm: FormGroup;
	paymentForm: FormGroup;
  card: any;
  //cardHandler = this.onChange.bind(this);

	uid: string;
	StoreName: string;
	email: string;
	Website: string;
	Country: string;
	PhoneNumber: string;
	Address: string;
	StorKey: string;
	Subid: string;
	SubCus: string;

	urid: string;
	NumberOfStores: string;
	MonthlyPlan: string;

	handler: any;
  	amount = 5;

	authState: any;
	payment: any;
	user1: any;
	user2: any;
	result: any[];
	values: any;
	userId: string;
	error: any;
	success: any;
	id: string;
	options: any[];
	nopaymentclass: any;
	user: any;
	setingres: any;
	country: any;
	countrylist: any;
	countoptions: any[];
	totalstor: any;
	totalstor1: any;

	totalsubquantity: any;
	BusinessCountry: any;
	busisCoun: string;
	CountryName: any;
	usercountry: string;
	taxrate: any;
	inputEl: ElementRef;
  	valueOnBlur: string;

	ValidAddress: any;
	UpdateValidAddress: any;

  	latitude: number;
  	longitude: number;
  	addressinfo: string;
  	AddressLongitude: string;
  	AddressLatitude: string;
  	UserDetails: any;
  	UName: string;
	UEmail: string;
	tax_percent: string;
	SubscribId:any;
	PlanId:any;
	subscription_item:any;
	CusscribId:any;
	BusinessPin:any;
	busisPin:any;
	markimage:any;
	GetPrice:any;
	buttonDisabled:boolean;
	disbtn: any;
  constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router,private paymentSvc: PaymentService,private http: HttpClient, private cd: ChangeDetectorRef, private formBuilder: FormBuilder) { 
  	this.angularAuth.authState.subscribe((auth) => {
        this.authState = auth
        if (auth) this.userId = auth.uid
        if(auth) {
        	this.userId = auth.uid
        	let options=[];
        	let ActStore=[];
	        this.user1 = this.db.list('/store/'+this.authState.uid).valueChanges();
	            this.user1.subscribe(res => {
	            this.result = res
	            console.log(res);
	            this.totalstor1 = res.length;
	            for (var i = 0; i < res.length; i++) {
	            	 var obj = i;
	            	options.push(obj);
	            	console.log(res[i]['subscriptions']);
	            	console.log(res[i]['isdeleted']);
	            	if(res[i]['isdeleted']==''){
	            		ActStore.push(obj);
	            	}
			    }
			    console.log(ActStore);
			    this.totalstor = ActStore.length;
			    console.log(this.totalstor);
			    //console.log(options);
			    this.options = options;
		    });
	       /* var ref = firebase.database().ref('/store/'+this.authState.uid);
      				let Sub = [];
	        	ref.on("value", function(snapshot) {
			   			Sub = snapshot.val();
			        }, function (errorObject) {
			          console.log("The read failed: " + errorObject.code);
			        });
			console.log(Sub);*/
	        this.user2 = this.db.object('/payments/'+this.authState.uid).valueChanges();
	            this.user2.subscribe(res => {
	            if(res){
	            this.payment = res
	            this.totalsubquantity = this.payment.quantity;
	            this.SubscribId = this.payment.id;
	            this.PlanId = this.payment.planid;
	            this.subscription_item = this.payment.subscription_item;
	            this.CusscribId = this.payment.customer;
		            if(this.payment.status=='active'){
		            	this.nopaymentclass = "greenstore";
		            } else {
		            	this.nopaymentclass = "redstore";	
		            }
	            } else {
	            	this.nopaymentclass = "redstore";
	            }
	            console.log(this.nopaymentclass);
		    });
	        this.user = this.db.object('/setting').valueChanges();
		      this.user.subscribe(res => {
		        this.setingres = res
		        console.log(this.setingres);
		    });
		    this.BusinessCountry = this.db.object('/users/'+this.authState.uid+'/CountryName').valueChanges();
		      this.BusinessCountry.subscribe(res => {
		        this.busisCoun = res
		        if(this.busisCoun != 'United Kingdom'){
		        	this.taxrate = 0;
		        } else {
		        	this.taxrate = 20;
		        }
		    });
		    this.BusinessPin = this.db.object('/users/'+this.authState.uid+'/pin').valueChanges();
		      	this.BusinessPin.subscribe(res => {
		      	this.busisPin = res
		      	if(this.busisPin=='Co-working Office'){
		      		this.markimage = 'assets/baseline_business.png';
		      	} else if(this.busisPin=='Gym'){
		      		this.markimage = 'assets/baseline_fitness_center.png';
		      	} else if(this.busisPin=='Restaurant'){
		      		this.markimage = 'assets/baseline_restaurant.png';
		      	} else if(this.busisPin=='Cafe') {
		      		this.markimage = 'assets/baseline_free_breakfast.png';
		      	} else {
		      		this.markimage = 'assets/map-marker-icon.png';
		      	}
		      	console.log(this.markimage);
		    });
		    let countoptions=[];
	        this.country = this.db.object('/Countries').valueChanges();
		      this.country.subscribe(res => {
		        this.countrylist = res.Country
		        this.countoptions = this.countrylist.split(',');
		        console.log(this.countoptions);
		    });
	    } else {
	    	this.router.navigate(['/login']);
	    }
	});
  }

  	valaddrs:any;
    isValidFormSubmitted: boolean;
    ngOnInit() {
    	this.buttonDisabled= false;
    	this.disbtn = 'yesdisable';
  		this.valaddrs = 'valiaddrs';
    	this.CrAmount = 0;
    	this.Quantity = 0;
    	this.GetPrice  = 'Nocheck';
    	this.popupname = "";
    	this.MName = '';
    	this.Prorate = 0;
		this.userForm = this.formBuilder.group({
			//uid: new FormControl(''),
		   StoreName: new FormControl('', Validators.required),
		   email: new FormControl(''),
		   Website: new FormControl(''),
		   PhoneNumber: new FormControl(''),
		   Country: new FormControl('United Kingdom', Validators.required),
		   Address: new FormControl('', Validators.required),
		   AddressLatitude: new FormControl(''),
		   AddressLongitude: new FormControl(''),
		   ValidAddress: new FormControl(''),
		});

		this.paymentForm = this.formBuilder.group({
			//urid: new FormControl(''),
			email: new FormControl(''),
			Subid: new FormControl(''),
			SubCus: new FormControl(''),
			NumberOfStores: new FormControl(''),
		    taxrate: new FormControl(''),
		    tolamont: new FormControl(''),
		    MonthlyPlan: new FormControl(null, Validators.required),
		}); 
	}

	isFieldValid(field: string) {
	    return !this.userForm.get(field).valid && this.userForm.get(field).touched;
	  }

	displayFieldCss(field: string) {
	    return {
	      'has-error': this.isFieldValid(field),
	      'has-feedback': this.isFieldValid(field)
	    };
	}


	redbtnvalue: any;
  	numstrovalue: any;
  	tax: any;
  	amountwithtax: any;
  	tolamont: any;
  	radioChange(event) {
  		this.redbtnvalue = event.target.defaultValue;
  		console.log(this.redbtnvalue);
  		this.numstrovalue = this.paymentForm.get('NumberOfStores').value;
  		console.log(this.redbtnvalue);
  		if(this.redbtnvalue == 'monthly'){
	    	this.subyplan = `${this.setingres.MonthlySubscriptions.PlanName}`;
	    	this.rate = `${this.setingres.MonthlySubscriptions.PlanRate}`;
	    }
	    if(this.redbtnvalue == 'yearly'){
	    	this.subyplan = `${this.setingres.YearlySubscriptions.PlanName}`;
	    	this.rate = `${this.setingres.YearlySubscriptions.PlanRate}`;
	    }
  		this.tax = this.paymentForm.get('taxrate').value;
  		if(this.tax == 0){
  			this.amountwithtax = 0;	
  		} else {
  			this.amountwithtax = (((this.rate)*(this.numstrovalue))*this.tax)/100;
  		}
		this.tolamont = ((this.rate)*(this.numstrovalue))+(this.amountwithtax);
		console.log(this.amountwithtax);
		console.log(this.tolamont);
	    //console.log(event.target.defaultValue);
	    //console.log(this.paymentForm.get('NumberOfStores').value);
	}
	fielderror:any;
    onFormSubmit() {
	   //this.isValidFormSubmitted = false;
	   console.log(this.userForm.status)
	   if(this.userForm.invalid){
	   		this.validateAllFormFields(this.userForm);
	   		this.error = "Please enter requires fields.";
	   		this.fielderror = "Please enter requires fields.";
	   		this.success = "";
		  //return;	
	   } 	
	   if(this.userForm.valid){
		   //this.isValidFormSubmitted = true;
		   //this.uid = this.userForm.get('uid').value;
		   this.StoreName = this.userForm.get('StoreName').value;
		   this.email = this.userForm.get('email').value;
		   this.Website = this.userForm.get('Website').value;
		   this.PhoneNumber = this.userForm.get('PhoneNumber').value;
		   this.Country = this.userForm.get('Country').value;
		   this.Address = this.userForm.get('Address').value; 
		   this.ValidAddress = this.userForm.get('ValidAddress').value;
		   this.AddressLatitude = this.userForm.get('AddressLatitude').value;
		   this.AddressLongitude = this.userForm.get('AddressLongitude').value;
			var str = this.StoreName;
		    var res = str.split(' ').join('-');
		    var text = "";
	   		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	 		for (var i = 0; i < 10; i++)
	    	text += possible.charAt(Math.floor(Math.random() * possible.length));
	    	const user = { text : this.Address};
			const headers = new HttpHeaders()
		      .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/getaddress`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      console.log(data);
		      const payment = { data }
		      	console.log(data['status']);
		      	console.log(data['text']);
		      	var contact = JSON.parse(data['text']);
				console.log(contact['status']);
				if(contact['status'] == 'OK'){
					if(this.ValidAddress != 'No'){
						this.db.object(`/store/${this.userId}/`+text).set({
				          	Name: this.StoreName,
				          	Email: this.email,
				          	Website: this.Website,
				          	PhoneNumber: this.PhoneNumber,
				          	Address: this.Address,
				          	Country: this.Country,
				          	StorKey: text,
				          	Latitude:this.AddressLatitude,
				          	Longitude:this.AddressLongitude,
					        subscriptions: 'inactive',
					        isdeleted: '',
                            sub:0,
                            PaymentFail:'No',
				      	});
				      	var StoreLat = parseFloat(this.AddressLatitude);
				      	var StoreLong = parseFloat(this.AddressLongitude);
					   	var firebaseRef = firebase.database().ref(`/locations/`);
						var geoFire = new GeoFire(firebaseRef);
						geoFire.set(text, [StoreLat, StoreLong]).then(function() {
						  	console.log("Provided key has been added to GeoFire");
						}, function(error) {
						  	console.log("Error: " + error);
						});

				      	this.success = "Sotre Created.";
					    this.error = "";
						this.fielderror="";
					    this.userForm.reset();
						//this.router.navigate(['/subscriptions']);
						location.reload();
					} else {
						this.error = "Please validate address";
						this.valaddrs = 'valiaddrs';
					}
				} else {
					this.ValidAddress = 'No';
					this.error = "Please enter valid address";
					this.valaddrs = 'valiaddrs';
				}
			});
			   	
		}
	}
	validateAllFormFields(formGroup: FormGroup) {
	    Object.keys(formGroup.controls).forEach(field => {
	      console.log(field);
	      const control = formGroup.get(field);
	      if (control instanceof FormControl) {
	        control.markAsTouched({ onlySelf: true });
	      } else if (control instanceof FormGroup) {
	        this.validateAllFormFields(control);
	      }
	    });
	}
	googleMap(){
    	this.error = "";
		this.popupname = "mapmodel";
		this.MName = '';
    	this.Address = this.userForm.get('Address').value;
    	this.addressinfo = '';
    	console.log(this.Address);
    	if(this.Address != null && this.Address != ''){
	    	console.log(this.Address);
	    	this.error = "Please wait...";
	    	const user = { text : this.Address};
			const headers = new HttpHeaders()
		      .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/getaddress`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      const payment = { data }
		      	var contact = JSON.parse(data['text']);
				if(contact['status'] == 'OK'){
					this.valaddrs = 'grenbtn';
					this.ValidAddress = 'Yes';
					this.latitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.longitude = contact['results'][0]['geometry']['location']['lng'];
	  				this.AddressLatitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.AddressLongitude = contact['results'][0]['geometry']['location']['lng'];
			    	this.addressinfo =  contact['results'][0]['formatted_address'];
			    	this.display='block';
					this.Address = contact['results'][0]['formatted_address'];
					this.error = "";
				} else {
					this.error = "Please enter valid address";
					this.valaddrs = 'valiaddrs';
			    }
			});
		} else {
			this.error = "Please enter valid address";
			this.valaddrs = 'valiaddrs';
		}
    }

	UpdateError: string;
    UpdategoogleMap(event, Address){

    	this.error = "";
    	this.Address = Address;
    	this.addressinfo = '';
    	if(this.Address != null && this.Address != ''){
	    	console.log(this.Address);
	    	this.UpdateError = "Please wait...";
	    	const user = { text : this.Address};
			const headers = new HttpHeaders()
		      .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/updategetaddress`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      console.log(data);
		      const payment = { data }
		      	var contact = JSON.parse(data['text']);
				if(contact['status'] == 'OK'){
					this.ValidAddress = 'Yes';
					this.latitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.longitude = contact['results'][0]['geometry']['location']['lng'];
	  				this.AddressLatitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.AddressLongitude = contact['results'][0]['geometry']['location']['lng'];
			    	this.addressinfo =  contact['results'][0]['formatted_address'];
			    	this.display='block';
					this.Address = contact['results'][0]['formatted_address'];
					//this.error = "";
					this.UpdateError = "";
				} else {
					this.UpdateError = "Please enter valid address";
			    }
			});
		} else {
			this.UpdateError = "Please enter valid address";
		}
    }
    placeMarker($event){
    	this.latitude = $event.coords.lat;
    	this.longitude = $event.coords.lng;
    	this.AddressLongitude = $event.coords.lng;
  		this.AddressLatitude = $event.coords.lat;
    	const user = { latitude : this.latitude, longitude: this.longitude};
		const headers = new HttpHeaders()
	      .set('Content-Type', 'application/json');
	    this.http.post(`https://nodestripepayment.herokuapp.com/getaddressname`, JSON.stringify(user), {
	      headers: headers
	    })
	    .subscribe(data => {
	      //console.log(data);
	      //console.log(data['status']);
	      	var contact = JSON.parse(data['text']);
	      	//console.log(contact['results']);
	      	this.addressinfo =  contact['results'][0]['formatted_address'];
	      	this.Address = contact['results'][0]['formatted_address'];
	  	});
  	}
	Name: string;
    updateprofile( event , StoreName, StorKey, Website, email, Country, PhoneNumber, Address, UpdateValidAddress, AddressLatitude, AddressLongitude) {
	   	console.log('as');
    	console.log(Address);
    	console.log('asd');
    	if(StoreName != null && Country != null && Address != null && StoreName != '' && Country != '' && Address != ''){
    		console.log(Address);
    		this.UpdateError = "Please Wait...";
    		const user = { text : Address};
			const headers = new HttpHeaders()
		      .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/getaddress`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      //console.log(data);
		      const payment = { data }
		      	//console.log(data['status']);
		      	var contact = JSON.parse(data['text']);
				//console.log(contact['status']);
				if(contact['status'] == 'OK'){
					this.AddressLongitude = contact['results'][0]['geometry']['location']['lng'];
	  				this.AddressLatitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.addressinfo =  contact['results'][0]['formatted_address'];
					   this.db.object(`/store/${this.userId}/`+StorKey).update({
				          Name: StoreName,
				          Email: email,
				          Website: Website,
				          PhoneNumber: PhoneNumber,
				          Address: this.addressinfo,
				          Country: Country,
				          StorKey: StorKey,
				      	  Latitude: this.AddressLongitude,
				      	  Longitude: this.AddressLatitude,
				      	});
					   	var StoreLat = parseFloat(this.AddressLatitude);
				      	var StoreLong = parseFloat(this.AddressLongitude);
					   	var firebaseRef = firebase.database().ref(`/locations/`);
						var geoFire = new GeoFire(firebaseRef);
						geoFire.set(StorKey, [StoreLat, StoreLong]).then(function() {
						  	console.log("Provided key has been added to GeoFire");
						}, function(error) {
						  	console.log("Error: " + error);
						});
					   //this.router.navigate(['/subscriptions']);
					   this.UpdateError = "";
					   this.UpdateValidAddress = "No";
					   location.reload();
				} else {
					this.UpdateValidAddress = "No";
					this.UpdateError = "Please enter valid address";
				}
			});
		} else {
			this.UpdateError = "Please enter all fields";
			this.UpdateValidAddress = "No";
		}
	}
	/*deletestore( event , StorKey) {
	   this.db.object(`/store/${this.userId}/`+StorKey).remove();
	   this.router.navigate(['/editsubscriptions']);
	   location.reload();
	   
	}*/
	stroId: any;
	StorSub: any;
	deletestore( event , StorKey, subscriptions) {
		this.popupname = "deletemodel";
		this.stroId = StorKey;
		this.StorSub = subscriptions;
		if(subscriptions=='active'){
			this.MName = 'deletemodel';
			this.display='block';
		} else {
			this.db.object(`/store/${this.userId}/`+StorKey).remove();
			this.db.object(`/locations/`+StorKey).remove();
			location.reload();
		}
	}
	undostore( event , StorKey) {
		this.db.object(`/store/${this.userId}/`+StorKey).update({
			isdeleted: '',
		});
		location.reload();
	}
	newstor:any;
	StoreDelete( event , StorKey1, subscriptions1) {
		this.db.object(`/store/${this.userId}/`+StorKey1).update({
			isdeleted: 'deleted',
		});
		/*if(subscriptions1=='active'){
			this.tolstore = `${this.totalsubquantity}`;
			this.newstor = this.tolstore-1; 
	  		this.newsubid = `${this.SubscribId}`;
	  		var proration_date = Math.floor(Date.now() / 1000);
	  		const user = { subid: this.newsubid, NoStore : this.newstor, proration_date : proration_date };
	  		const headers = new HttpHeaders()
	          .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/subscribUpdate`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      console.log(data);
		      const payment = { data }
		      	//this.db.list(`/payments/${this.userId}`).remove();
		      	this.db.object(`/payments/${this.userId}`).update({
		          	billing: data['billing'],
		          	billing_cycle_anchor: data['billing_cycle_anchor'],
		          	cancel_at_period_end: data['cancel_at_period_end'],
		          	canceled_at: data['canceled_at'],
		          	created: data['created'],
		          	current_period_end: data['current_period_end'],
		          	current_period_start: data['current_period_start'],
		          	//customer:data['customer'],
		          	id:data['id'],
		          	//quantity: data['quantity'],
		          	start: data['start'],
		          	//status: data['status'],
		          	tax_percent: data['tax_percent'],
		          	object: data['object'],
		          	amount: data['plan']['amount'],
		          	currency: data['plan']['currency'],
		          	nickname:data['plan']['nickname'],
		          	product:data['plan']['product'],
			        eventtype: 'subupdate',
		      	});
		    });
		}*/
		location.reload();
	}
	 	
  	//payment:string;
  	total:any;
  	Taxes:any;
  	monthlyplan: any;
  	yearlyplan: any;
  	subyplan: any;
  	display='none';
  	error1: any;
  	tltplan: any;
  	rate: any;
  	paymenFormSubmit() {
	    if(this.paymentForm.invalid){
		  return;	
	    }
		    this.email = this.paymentForm.get('email').value;
		    this.NumberOfStores = this.paymentForm.get('NumberOfStores').value;
		    this.Subid = this.paymentForm.get('Subid').value;
		    this.SubCus = this.paymentForm.get('SubCus').value;
		    this.MonthlyPlan = this.paymentForm.get('MonthlyPlan').value;
		    if(this.MonthlyPlan == 'monthly'){
		    	this.subyplan = `${this.setingres.MonthlySubscriptions.PlanName}`;
		    	this.rate = `${this.setingres.MonthlySubscriptions.PlanRate}`;
		    }
		    if(this.MonthlyPlan == 'yearly'){
		    	this.subyplan = `${this.setingres.YearlySubscriptions.PlanName}`;
		    	this.rate = `${this.setingres.YearlySubscriptions.PlanRate}`;
		    }

		    this.Taxes = `${this.setingres.Taxes}`;
		    this.Taxes = (((this.rate)*(this.paymentForm.get('NumberOfStores').value))*20)/100;
		    this.total = (this.rate)*(this.paymentForm.get('NumberOfStores').value)+(this.Taxes);
		    console.log(this.Subid);
		    console.log(this.SubCus);
		    this.error1 = "";
		    const user = { text : this.email, plan : this.subyplan, subid: this.Subid, NoStore : this.NumberOfStores, SubCus: this.SubCus };
	  		const headers = new HttpHeaders()
	          .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/subUpdate`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      console.log(data);
		      const payment = { data }
     			this.router.navigate(['/mysubscriptionsplan']);
		    });
		//}
  	}
  	tolstore:any;
  	newstore:any;
  	finalstore:any;
  	newsubid:any;
  	prorate:any;
  	newcusid:any;
  	SubscribUpdate( event , newamont){
  		this.tolstore = `${this.totalstor}`;
  		console.log(this.tolstore);
  		this.Quantity = `${this.totalsubquantity}`;
  		console.log(this.Quantity);
  		var tax = `${this.taxrate}`;
  		//this.finalstore = (this.tolstore)-(this.newstore)
  		if(	parseInt(this.tolstore)<=parseInt(this.Quantity)){
  			this.prorate = 'false';
  		} else {
  			this.prorate = 'true';
  		}
  		console.log(this.prorate);
  		this.newsubid = `${this.SubscribId}`;
  		this.newcusid = `${this.CusscribId}`;
  		var proration_date = Math.floor(Date.now() / 1000);
  		const user = { subid: this.newsubid, cusid: this.newcusid, amount: newamont, NoStore : this.tolstore, proration_date : proration_date, prorate : this.prorate, tax_percent: tax };
  		const headers = new HttpHeaders()
          .set('Content-Type', 'application/json');
	    this.http.post(`https://nodestripepayment.herokuapp.com/subscribUpdate`, JSON.stringify(user), {
	      headers: headers
	    })
	    .subscribe(data => {
	    	if(	this.tolstore==this.Quantity){
	    		var usrid =`${this.userId}`;
	  			//var db1 = firebase.database().ref(`/advertising/${this.userId}/`+stid+`/offer`);
	  			var ref = firebase.database().ref('/store/'+usrid);
  				let Sub = [];
		   		ref.on("value", function(snapshot) {
		   			Sub = snapshot.val();
		        }, function (errorObject) {
		          console.log("The read failed: " + errorObject.code);
		        });
		        if(Sub == null){
		        	var lenth = 0;
		        } else {
		        	var o = Sub;
					var arr = Object.keys(o).map(function(k) { return o[k] });
		        }
	        	var k=0;
	        	for (var j = 0; j < arr.length; j++) {
	   				if(arr[j].sub!=1){
				        firebase.database().ref('/store/'+usrid+'/'+arr[j].StorKey).update({
							"subscriptions": 'active',
							"sub":1,
						});
				    }
		   		}
		   		var ref1 = firebase.database().ref('/store/'+usrid);
				ref1.orderByChild('isdeleted').equalTo('deleted').once("value",(snapshot) => {
					snapshot.forEach((childSnapshot) => {
					    var storid = childSnapshot.key;
						var keys = snapshot.key;
						firebase.database().ref('/store/'+usrid+'/'+storid).remove();
                        firebase.database().ref('/locations/'+storid).remove();
					    return true; 
					});
				});
	  		}
		    this.disbtn = 'yesdisable';
	      	console.log(data);
	      	const payment = { data }
	      	//this.db.list(`/payments/${this.userId}`).remove();
	      	this.db.object(`/payments/${this.userId}`).update({
	          	billing: data['billing'],
	          	billing_cycle_anchor: data['billing_cycle_anchor'],
	          	cancel_at_period_end: data['cancel_at_period_end'],
	          	canceled_at: data['canceled_at'],
	          	created: data['created'],
	          	current_period_end: data['current_period_end'],
	          	current_period_start: data['current_period_start'],
	          	//customer:data['customer'],
	          	id:data['id'],
	          	//quantity: data['quantity'],
	          	start: data['start'],
	          	//status: data['status'],
	          	tax_percent: data['tax_percent'],
	          	object: data['object'],
	          	amount: data['plan']['amount'],
	          	currency: data['plan']['currency'],
	          	nickname:data['plan']['nickname'],
	          	product:data['plan']['product'],
		        eventtype: 'subupdate',
	      	});
 			//this.db.list(`/payments/${this.userId}`).push(data);
 			//location.reload();
 			window.location.href = "https://nodestripepayment.herokuapp.com/mysubscriptionsplan";
 			//this.router.navigate(['/mysubscriptionsplan']);
	    });
  		

  	}
  	popupname:any;
  	check:any;
  	MName:any;
	UpdatePopup(){
		this.tolstore = `${this.totalstor}`;
  		this.newstore = `${this.totalsubquantity}`;
  		//console.log(this.newstore);
  		this.finalstore = (this.tolstore)-(this.newstore);
		this.popupname = "updatemodel";
		this.MName = 'subupdtmodel';
		this.check = `${this.GetPrice}`;
		//if(this.finalstore>0){
			if(this.check=='PriceCheck'){
				this.display='block';
			} else {
				this.error1= "Please Preview Price.";
			}
		/*} else {
			this.error1= "Your all store subscribe now.";
			this.GetPrice = 'Nocheck';
		}*/
	}
  	
  	onCloseHandled(){
       this.display='none'; 
    }
  	SubsDelete(){
  		this.display='block';
  	}
  	onCancleNow(){
  		this.Subid = this.paymentForm.get('Subid').value;
		const user = { id : this.Subid};
  		const headers = new HttpHeaders()
          .set('Content-Type', 'application/json');
	    this.http.post(`https://nodestripepayment.herokuapp.com/canclenow`, JSON.stringify(user), {
	      headers: headers
	    })
	    .subscribe(data => {
	        console.log(data);
	        this.db.list(`/payments/${this.userId}`).remove();
	       // this.db.list(`/payments/${this.userId}`).push(data)
	      	this.db.object(`/payments/${this.userId}`).set({
	          	billing: data['billing'],
	          	billing_cycle_anchor: data['billing_cycle_anchor'],
	          	cancel_at_period_end: data['cancel_at_period_end'],
	          	canceled_at: data['canceled_at'],
	          	created: data['created'],
	          	current_period_end: data['current_period_end'],
	          	current_period_start: data['current_period_start'],
	          	customer:data['customer'],
	          	id:data['id'],
	          	quantity: data['quantity'],
	          	start: data['start'],
	          	status: data['status'],
	          	tax_percent: data['tax_percent'],
	          	object: data['object'],
	          	amount: data['plan']['amount'],
	          	currency: data['plan']['currency'],
	          	nickname:data['plan']['nickname'],
	          	product:data['plan']['product'],
		        eventtype: 'subupdate',
	      	});
	    });
  	}
  	onCancelEnd(){
  		this.Subid = this.paymentForm.get('Subid').value;
		const user = { id : this.Subid};
  		const headers = new HttpHeaders()
          .set('Content-Type', 'application/json');
	    this.http.post(`https://nodestripepayment.herokuapp.com/cancleend`, JSON.stringify(user), {
	      headers: headers
	    })
	    .subscribe(data => {
	        console.log(data);
	        this.db.list(`/payments/${this.userId}`).remove();
	        //this.db.list(`/payments/${this.userId}`).push(data)
	        this.db.object(`/payments/${this.userId}`).set({
	          	billing: data['billing'],
	          	billing_cycle_anchor: data['billing_cycle_anchor'],
	          	cancel_at_period_end: data['cancel_at_period_end'],
	          	canceled_at: data['canceled_at'],
	          	created: data['created'],
	          	current_period_end: data['current_period_end'],
	          	current_period_start: data['current_period_start'],
	          	customer:data['customer'],
	          	id:data['id'],
	          	quantity: data['quantity'],
	          	start: data['start'],
	          	status: data['status'],
	          	tax_percent: data['tax_percent'],
	          	object: data['object'],
	          	amount: data['plan']['amount'],
	          	currency: data['plan']['currency'],
	          	nickname:data['plan']['nickname'],
	          	product:data['plan']['product'],
		        eventtype: 'subupdate',
	      	});
	    });
  	}
  	Cid:any;
  	CrAmount:any;
  	Quantity:any;
  	Prorate:any;
  	UpcomiInvoive(){
  		this.tolstore = `${this.totalstor}`;
  		this.newstore = `${this.totalsubquantity}`;
  		this.finalstore = (this.tolstore)-(this.newstore);
		this.popupname = "updatemodel";
		this.GetPrice = 'PriceCheck';
		//if(this.finalstore>0){
			var proration_date = Math.floor(Date.now() / 1000);
  			var tax = `${this.taxrate}`;
  			this.newsubid = `${this.SubscribId}`;
  			var PlanIds = `${this.PlanId}`;
  			var subscription_item = `${this.subscription_item}`;
	  		this.Cid = `${this.CusscribId}`;
	  		const user = { id : this.Cid, proration_date:proration_date, quantity:this.tolstore,subid:this.newsubid, tax:tax, PlanIds:PlanIds, subscription_item:subscription_item};
	  		const headers = new HttpHeaders()
	          .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/upcominginvoice`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		    	this.buttonDisabled=true;
		    	this.disbtn = 'nodisable';
		        console.log(data);
		        //console.log(data['lines']);
		        console.log(data['lines']['data'][0]['plan']['amount']);
		        this.CrAmount = parseInt(data['lines']['data'][0]['plan']['amount']);
		        this.Quantity = parseInt(data['lines']['data'][0]['quantity']);
		        var tax = parseInt(`${this.taxrate}`);
		        var tltstor = parseInt(`${this.totalstor}`);
		        /*if(tax != 0){
		        	this.Prorate = ((((tltstor-this.Quantity)*(this.CrAmount / 100))*tax)/100) + ((tltstor-this.Quantity)*(this.CrAmount / 100));
		        } else {
		        	this.Prorate = ((tltstor-this.Quantity)*(this.CrAmount / 100));
		        }
		        if(this.Prorate>0){
		        	this.Prorate = this.Prorate;
		        } else {
		        	this.Prorate = 0;
		        }*/
		        console.log(this.Quantity);
		        //console.log(data['lines']['data'][0]['plan'].quantity);
		        const current_prorations = [];
				var cost = 0;
				//const proration_date = Math.floor(Date.now() / 1000);
				for (var i = 0; i < data['lines']['data'].length; i++) {
				  const invoice_item = data['lines']['data'][i];
				  if (invoice_item.period.start < proration_date) {
				    current_prorations.push(invoice_item);
				    cost += invoice_item.amount;
				  }
				}
				//this.CrAmount = cost;
				//console.log(cost);
				var cost1 = 0;
				for (var i = 0; i < data['lines']['data'].length; i++) {
				  const invoice_item = data['lines']['data'][i];
				  if (invoice_item.period.start == proration_date) {
				    current_prorations.push(invoice_item);
				    cost1 += invoice_item.amount;
				  }
				}
				console.log(current_prorations);
				console.log(cost1);
				this.Prorate = cost1;
				if(tax != 0){
		        	this.Prorate = (((this.Prorate)*tax)/100) + (this.Prorate);
		        } else {
		        	this.Prorate = this.Prorate;
		        }
				if(this.Prorate>0){
		        	this.Prorate = this.Prorate;
		        } else {
		        	this.Prorate = 0;
		        }

		        //this.db.list(`/payments/${this.userId}`).remove();
		    });
		/*} else {
			this.error1= "You already subscribe for all store.";
		}*/
  	}
}
