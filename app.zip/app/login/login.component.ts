import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { moveIn } from '../router.animations';
import * as firebase from 'firebase/app';
import CryptoJS from 'crypto-js';
import * as myGlobals from '../../globals';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  userid: string;
  authState: any;
  screenWidth: number;
  userId: string;
  user: any;
  result: any;
user1: any;
MonthlyPlanRate:any;
YearlyFreeSub:any;
YearlyPlanRate:any;

  userName: string;
  email: string;

  constructor(private angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router,private http: HttpClient) {
    this.screenWidth = window.innerWidth;
    window.onresize = () => {
      // set screenWidth on screen size change
      this.screenWidth = window.innerWidth;
    };
    this.angularAuth.authState.subscribe((auth) => {
        this.authState = auth
        if(auth) {
          this.userId = auth.uid
          this.user1 = this.db.object('/users/'+this.authState.uid).valueChanges();
          this.user1.subscribe(res => {
            this.result = res
            if(this.result.CompanyName != null && this.result.CountryName != null && this.result.Email != null && this.result.Name != null && this.result.PhoneNumber != null && this.result.pin != null){
              //this.nodata = "alldata";
              //this.router.navigate(['/advertising']);
              window.location.href = "https://nodestripepayment.herokuapp.com/advertising";
            } else {
              //this.nodata = "noalldata";
              //this.router.navigate(['/userregistration']);
              window.location.href = "https://nodestripepayment.herokuapp.com/userregistration";
            }
          });
          //this.router.navigate(['/advertising']);
      } else {
        this.router.navigate(['/login']);
      }
    });
    this.MonthlyPlanRate = myGlobals.MonthlyPlanRate;
    this.YearlyFreeSub = myGlobals.YearlyFreeSub;
    this.YearlyPlanRate = myGlobals.YearlyPlanRate;
    // this.user = this.db.object('/setting').valueChanges();
    //   this.user.subscribe(res => {
    //     this.result = res
    //     console.log(this.result);
    // });
	}

  ngOnInit() {
    /*this.db.object('/setting').set({
      MonthlyPlan: '$7.50',
      YearlyPlan: '£75',
    });*/
    this.angularAuth.auth.onAuthStateChanged(firebaseUser => {
      if(firebaseUser){
        var user = firebase.auth().currentUser;
        var textString = user.displayName; // Utf8-encoded string
        var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
        var base64 = CryptoJS.enc.Base64.stringify(words);
        this.userName = base64;

        var textString = user.email; // Utf8-encoded string
        var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
        var base64 = CryptoJS.enc.Base64.stringify(words);
        this.email = base64;
        //console.log(user);
        if (user != null) {
          this.db.object('/users/'+user.uid).snapshotChanges().subscribe(res1 => {
            if(res1.key == null){
              var firebaseRef = firebase.database().ref();
              var usersRef = firebaseRef.child("users");
              usersRef.child(this.angularAuth.auth.currentUser.uid).set({
                  Name: this.userName,
                  Email: this.email,
                  Password: '',
                  UserId: user.uid,
                  PhotoURL: user.photoURL,
              });
              this.router.navigate(['/userregistration']);
            } else {
              //this.router.navigate(['/advertising']);
            }
          });
        }
        //this.router.navigate(['/profile']);
      } else{

      }

    });
  }

  signInWithFacebook() {
     this.angularAuth.auth.signInWithPopup(new firebase.auth.FacebookAuthProvider())
    .then((res) => { 
      //console.log(res);
        // const userEmail = { uid : res.user.uid};
        // const headers = new HttpHeaders()
        //     .set('Content-Type', 'application/json');
        // this.http.post(`https://nodestripepayment.herokuapp.com/login`, JSON.stringify(userEmail), {
        //   headers: headers
        // })
        // .subscribe(data => {
        //     console.log(data);
        // });
      this.db.object('/users/'+res.user.uid).snapshotChanges().subscribe(res1 => {
       console.log(res);
            if(res1.key == null){
                console.log(res.user.email);
                var textString = res.user.displayName; // Utf8-encoded string
                var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
                var base64 = CryptoJS.enc.Base64.stringify(words);
                this.userName = base64;

                var textString = res.user.email; // Utf8-encoded string
                var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
                var base64 = CryptoJS.enc.Base64.stringify(words);
                this.email = base64;

                this.db.object('/users/'+res.user.uid).set({
                  Name: this.userName,
                  Email: this.email,
                  Password: '',
                  UserId: res.user.uid,
                  PhotoURL: res.user.photoURL,
                  });
                /*}).then(function(){
                  this.router.navigate(['/userregistration']);
                });*/
                //this.router.navigate(['/userregistration']);
            } else {
              console.log(res.user.uid);
              //this.router.navigate(['/advertising']);
            }
      });
      //this.router.navigate(['/profile']);
    })
    .catch(function(error) {
      alert(error.message);
      console.log(error); 
      //this.ErrorMsg = ErrorMsg;
      //console.log(error.message);
    });
  }
  

  login(){
    this.angularAuth.auth.signInWithPopup(new firebase.auth.GoogleAuthProvider()).then(res =>{
      // const userEmail = { uid : res.user.uid};
      // const headers = new HttpHeaders()
      //     .set('Content-Type', 'application/json');
      // this.http.post(`https://nodestripepayment.herokuapp.com/login`, JSON.stringify(userEmail), {
      //   headers: headers
      // })
      // .subscribe(data => {
      //     console.log(data);
      // });
     this.db.object('/users/'+res.user.uid).snapshotChanges().subscribe(res1 => {
       console.log(res);
            if(res1.key == null){
                console.log(res.user.email);
                var textString = res.user.displayName; // Utf8-encoded string
                var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
                var base64 = CryptoJS.enc.Base64.stringify(words);
                this.userName = base64;

                var textString = res.user.email; // Utf8-encoded string
                var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
                var base64 = CryptoJS.enc.Base64.stringify(words);
                this.email = base64;

                this.db.object('/users/'+res.user.uid).set({
                  Name: this.userName,
                  Email: this.email,
                  Password: '',
                  UserId: res.user.uid,
                  PhotoURL: res.user.photoURL,
                });
                const user = { email : res.user.email};
                const headers = new HttpHeaders()
                    .set('Content-Type', 'application/json');
                this.http.post(`https://nodestripepayment.herokuapp.com/subscription`, JSON.stringify(user), {
                  headers: headers
                })
                .subscribe(data => {
                  console.log(data);
                });
                //window.location.href = "https://nodestripepayment.herokuapp.com/userregistration";
              this.router.navigate(['/userregistration']);
            } else {
              //console.log(res.user.uid);
              //this.router.navigate(['/advertising']);
            }
      });
    });
  }
  login1(){
    var provider = new firebase.auth.GoogleAuthProvider();
    firebase.auth().signInWithRedirect(provider);
    //firebase.auth().signInWithRedirect(new firebase.auth.GoogleAuthProvider());
    this.angularAuth.auth.getRedirectResult().then(result =>{
     console.log(result);
    });
  }
}
