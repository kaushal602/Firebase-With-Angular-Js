import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'firebase/storage';
import * as firebase from 'firebase/app';

@Component({
  selector: 'app-mobilesidebar',
  templateUrl: './mobilesidebar.component.html',
  styleUrls: ['./mobilesidebar.component.css']
})
export class MobilesidebarComponent implements OnInit {
user1: any;
	authState: any;
	result: any = null;
	values: any;
	uid: string;
	userName: string;
	email: string;
	phonenumber: string;
	Country: string;
	companyname: string;
	Address: string;
	pin: string;
	UsrSubscribe: string;
	PhotoURL: string;
	ProfileImage: string;
	CompanyImage: string;
	selectedProfileFiles: FileList;
	selectedCompanyFiles: FileList;
	file: File;

	storageRef: any;
	storageRef1: any;
	storageRef2: any;
	comlogo: any;
	proimg: any;
  constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router) {
  		this.angularAuth.authState.subscribe((auth) => {
  			if(auth){
	            this.authState = auth

	            var x = this.db.object('/users').snapshotChanges().subscribe(res => {

	          	});
	            this.user1 = this.db.object('/users/'+this.authState.uid).valueChanges();
	            this.user1.subscribe(res => {
		            this.result = res
		            this.proimg = this.result.PhotoURL;
		            /*if(this.result.ProfileImage != null){
			            this.storageRef = firebase.storage().ref().child('/profile/'+this.result.ProfileImage);
						this.storageRef.getDownloadURL().then(profileurl => {
							this.proimg = profileurl ;
						});
					}*/
					this.comlogo = this.result.PhotoURL;
					if(this.result.CompanyImage != null || this.result.CompanyImage != ''){
						this.storageRef1 = firebase.storage().ref().child('/companylogo/'+this.result.CompanyImage);
						this.storageRef1.getDownloadURL().then(companylogo => {
							if(companylogo){
								this.comlogo = companylogo;
							}
						});
						/*this.storageRef1.getDownloadURL().then(function(url) {
				          	this.comlogo = url;
				        }).catch(function(error) {

				        });*/
					}
					/*if(this.result.CompanyImage){
						if(this.result.CompanyImage != null || this.result.CompanyImage != ''){
							this.storageRef1 = firebase.storage().ref().child('/companylogo/'+this.result.CompanyImage);
							this.storageRef1.getDownloadURL().then(companylogo => {
								this.comlogo = companylogo;
								//console.log(this.comlogo);
							});
						} else {
							this.storageRef2 = firebase.storage().ref().child('/photos/tree-logo.jpg');
							this.storageRef2.getDownloadURL().then(companylogo => {
								this.comlogo = companylogo;
								//console.log(this.comlogo);
							});
						}
					} else {
						this.storageRef2 = firebase.storage().ref().child('/photos/tree-logo.jpg');
						this.storageRef2.getDownloadURL().then(companylogo => {
							this.comlogo = companylogo;
							//console.log(this.comlogo);
						});
					}*/
		        });
	        }
		});
	}

  ngOnInit() {
  }
  logout() {
    	this.angularAuth.auth.signOut();
    	this.router.navigate(['/login']);
  	}
}
