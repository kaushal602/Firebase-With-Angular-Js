import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MysubscriptionsplanComponent } from './mysubscriptionsplan.component';

describe('MysubscriptionsplanComponent', () => {
  let component: MysubscriptionsplanComponent;
  let fixture: ComponentFixture<MysubscriptionsplanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MysubscriptionsplanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MysubscriptionsplanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
