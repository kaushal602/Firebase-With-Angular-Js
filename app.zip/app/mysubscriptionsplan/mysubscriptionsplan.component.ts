import { Component, OnInit, HostListener, AfterViewInit, OnDestroy, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { PaymentService } from '../payments/payment.service';
import { environment } from '../../environments/environment';
import 'firebase/storage';
import * as firebase from 'firebase/app';
import CryptoJS from 'crypto-js';


@Component({
  selector: 'app-mysubscriptionsplan',
  templateUrl: './mysubscriptionsplan.component.html',
  styleUrls: ['./mysubscriptionsplan.component.css']
})
export class MysubscriptionsplanComponent implements OnInit {
	uid: string;
	StoreName: string;
	email: string;
	Website: string;
	Country: string;
	PhoneNumber: string;
	Address: string;
	StorKey: string;

	urid: string;
	NumberOfStores: string;
	MonthlyPlan: number;

	handler: any;
  	amount = 5;
  	card: any;
  //cardHandler = this.onChange.bind(this);

	authState: any;
	user1: any;
	user2: any;
	result: any[];
	values: any;
	userId: string;
	SubsId: string;
	error: any;
	success: any;
	payment: any;
	paymentyes: any;
	nopaymentclass: any;
	user: any;
	setingres: any;
	country: any;
	countrylist: any;
	countoptions: any[];

	total:any;
  	Taxes:any;
  	monthlyplan: any;
  	yearlyplan: any;
  	subyplan: any;
  	display='none';
  	error1: any;
  	tltplan: any;
  	rate: any;
  	CustomerId: any;
  	modelname: any;
  	modelclass: any;
  	BusinessCountry: any;
	busisCoun: string;
	CountryName: any;
	usercountry: string;
	taxrate: any;
  	valueOnBlur: string;
  	UserDetails: any;
  	UName: string;
	UEmail: string;
	amot: number;
	quant: number;
	finalamont:number =7.5;
	Storeresult: any[];
  constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router,private paymentSvc: PaymentService,private http: HttpClient, private cd: ChangeDetectorRef,) { 
  	this.angularAuth.authState.subscribe((auth) => {
        this.authState = auth
        if(auth) this.userId = auth.uid
        if(auth) {
	        this.user1 = this.db.list('/store/'+this.authState.uid).valueChanges();
	            this.user1.subscribe(res => {
                this.result = res
                this.Storeresult = res
	            console.log(res);
		    });
	        this.user2 = this.db.object('/payments/'+this.authState.uid).valueChanges();
	            this.user2.subscribe(res => {
	            if(res){
		            this.payment = res
		            /*this.amot = this.payment.amount;
		            this.quant = this.payment.quantity;
		            this.finalamont = (this.amot*this.quant)/100;*/
		            this.SubsId = this.payment.id;
		            this.CustomerId = this.payment.customer;
		            console.log(res);
		            if(this.payment.status == 'active'){
		            	this.nopaymentclass = "greenstore";
		            } else {
		            	this.nopaymentclass = "redstore";	
		            }
	            } else {
	            	this.nopaymentclass = "redstore";
	            }
		            console.log(this.nopaymentclass);
		        //}
	            //console.log(this.payment[0].plan.nickname);
		    });
	        this.user = this.db.object('/setting').valueChanges();
		      this.user.subscribe(res => {
		        this.setingres = res
		        console.log(this.setingres);
		    });
		      this.BusinessCountry = this.db.object('/users/'+this.authState.uid+'/CountryName').valueChanges();
		      this.BusinessCountry.subscribe(res => {
		        this.busisCoun = res
		        if(this.busisCoun != 'United Kingdom'){
		        	this.taxrate = 0;
		        } else {
		        	this.taxrate = 20;
		        }
		    });
		    this.UserDetails = this.db.object('/users/'+this.authState.uid).valueChanges();
		      this.UserDetails.subscribe(res => {
		        //this.UserDetails = res
		        console.log(res);
		        var base64 = res.Name;
				var words = CryptoJS.enc.Base64.parse(base64);
				var textString = CryptoJS.enc.Utf8.stringify(words);
				this.UName = textString;

				var base64 = res.Email;
				var words = CryptoJS.enc.Base64.parse(base64);
				var textString = CryptoJS.enc.Utf8.stringify(words);
				this.UEmail = textString;
		    });
	        let countoptions=[];
	        this.country = this.db.object('/Countries').valueChanges();
		      this.country.subscribe(res => {
		        this.countrylist = res.Country
		        this.countoptions = this.countrylist.split(',');
		        console.log(this.countoptions);
		    });
	    } else {
	    	this.router.navigate(['/login']);
	    }
	});
  }
  ngOnInit() {
	  //this.paymentyes = "No";
	  this.finalamont = 7.5;
		this.display='none';
	  	this.modelname = '';
  		this.modelclass = '';
  		this.handler = StripeCheckout.configure({
	      key: environment.stripeKey,
	      image: '',
	      locale: 'auto',
	      token: token => {
	      	console.log(token);
	        //this.paymentSvc.processPayment(token, this.total, this.NumberOfStores)
	        console.log(token.id);
	        console.log(`${this.CustomerId}`);
	        //const user = { id : token.id, customerid : `${this.CustomerId}`};
	        const user = { id : token.card.id, customerid : `${this.CustomerId}`,tokenid : token.id, exp_month : token.card.exp_month, exp_year : token.card.exp_year, cardname : token.card.name, address_city: token.card.address_city, address_country: token.card.address_country, address_line1: token.card.address_line1, address_zip: token.card.address_zip, address_state:token.card.address_state};
	  		const headers = new HttpHeaders()
	          .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/updatecard`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		        console.log(data);
		        const user1 = {to:`${this.UEmail}`,Name:`${this.UName}`};
				const headers = new HttpHeaders()
		      		.set('Content-Type', 'application/json');
		      	this.http.post(`https://nodestripepayment.herokuapp.com/updatecardemail`, JSON.stringify(user1), {
			      	headers: headers
			    })
			    .subscribe(data => {
			    	console.log(data);
			    });
		       
		    });
	      }
	    });
  	}

  isValidFormSubmitted: boolean = null;
	
	Name: string;
    updateprofile( event , StoreName, StorKey, Website, email, Country, PhoneNumber, Address) {
	   this.db.object(`/store/${this.userId}/`+StorKey).update({
          Name: StoreName,
          Email: email,
          Website: Website,
          PhoneNumber: PhoneNumber,
          Address: Address,
          Country: Country,
          StorKey: StorKey,
      	});
	   this.router.navigate(['/mysubscriptionsplan']);
	}
	deletestore( event ,  StorKey) {
	   this.db.object(`/store/${this.userId}/`+StorKey).remove();
	   this.router.navigate(['/mysubscriptionsplan']);
	}

	UpdateCard(){
		this.handler.open({
	      	name: 'Workbudi - Stripe',
	      	email:`${this.authState.email}`,
	      	image: '/assets/wb-logo.png',
	      	currency: 'GBP',
	      	allowRememberMe: false,
	      	label:"Update Card Details",
	      	panelLabel:'Update Card Details',
	      	local: 'auto',
	      	address : true,
	      	description: 'Annual Or Monthly Subscription Plan',
    	});
	}
  	@HostListener('window:popstate')
	onPopstate() {
	  this.handler.close()
	}
	ngAfterViewInit() {
	    this.card = elements.create('card', {
		  hidePostalCode: true,
		  allowRememberMe: true,
		  style: {
		    base: {
		      iconColor: '#F99A52',
		      color: '#32315E',
		      lineHeight: '48px',
		      fontWeight: 400,
		      fontFamily: '"Open Sans", "Helvetica Neue", "Helvetica", sans-serif',
		      fontSize: '15px',

		      '::placeholder': {
		        color: '#CFD7DF',
		      }
		    },
		  }
		});
		//this.card.mount('#card-info');
	}
	
	ngOnDestroy() {
	    //this.card.removeEventListener('change', this.cardHandler);
    	this.card.destroy();
	}

	 /* onChange({ error }) {
	    if (error) {
	      this.error = error.message;
	    } else {
	      this.error = null;
	    }
	    this.cd.detectChanges();
	  }*/
  	
  	SubsDelete(event, SubId){
  		this.modelname = 'deletelmodel';
  		this.display='block';
  	}
  	DeleteNow(){
  		this.db.object(`/payments/${this.userId}`).update({
	       	eventtype: 'subdelete',
	       	quantity: '0',
        });
        
        for (var j = 0; j < this.Storeresult.length; j++) {
            console.log(this.Storeresult[j].StorKey);
            console.log(this.Storeresult[j]);
            this.db.list('/locations/'+this.Storeresult[j].StorKey).remove();
        }
        //this.db.list(`/users/${this.userId}`).update();
        this.db.list(`/store/${this.userId}`).remove();
        
        this.db.list(`/advertising/${this.userId}`).remove();
       
        const user1 = {to:`${this.UEmail}`,Name:`${this.UName}`};
		const headers = new HttpHeaders()
      		.set('Content-Type', 'application/json');
      	this.http.post(`https://nodestripepayment.herokuapp.com/deleteemail`, JSON.stringify(user1), {
	      	headers: headers
	    })
	    .subscribe(data => {
	    	console.log(data);
	    });
	    this.display='none';
		// const user = { id : `${this.SubsId}`};
  // 		const headers = new HttpHeaders()
  //         .set('Content-Type', 'application/json');
	 //    this.http.post(`https://nodestripepayment.herokuapp.com/subdelete`, JSON.stringify(user), {
	 //      headers: headers
	 //    })
	 //    .subscribe(data => {
	 //        console.log(data);
	 //        //this.db.list(`/payments/${this.userId}`).remove();
	        
 	// 		this.display='none';
	 //    });
  	}
  	alertmessage(){
  		this.modelname = '';
  		this.display='block';
  	}
  	onCloseHandled(){
       this.display='none'; 
    }
    

  	SubsCalcel(){
  		this.modelname = 'cancelmodel';
  		this.display='block';
  	}
  	onCancleNow(){
		const user = { id : `${this.SubsId}`};
  		const headers = new HttpHeaders()
          .set('Content-Type', 'application/json');
	    this.http.post(`https://nodestripepayment.herokuapp.com/canclenow`, JSON.stringify(user), {
	      headers: headers
	    })
	    .subscribe(data => {
	        console.log(data);
	        //this.db.list(`/payments/${this.userId}`).remove();
	        if(data['discount']){
	      		this.db.object(`/payments/${this.userId}`).update({
		          	billing: data['billing'],
		          	billing_cycle_anchor: data['billing_cycle_anchor'],
		          	cancel_at_period_end: data['cancel_at_period_end'],
		          	canceled_at: data['canceled_at'],
		          	created: data['created'],
		          	current_period_end: data['current_period_end'],
		          	current_period_start: data['current_period_start'],
		          	customer:data['customer'],
		          	id:data['id'],
		          	quantity: data['quantity'],
		          	start: data['start'],
		          	status: data['status'],
		          	tax_percent: data['tax_percent'],
		          	object: data['object'],
		          	amount: data['plan']['amount'],
		          	currency: data['plan']['currency'],
		          	nickname:data['plan']['nickname'],
		          	product:data['plan']['product'],
		          	couponid:data['discount']['coupon']['id'],
		          	percent_off:data['discount']['coupon']['percent_off'],
		          	eventtype: 'cancelnow',
		      	});
	      	} else {
	      		this.db.object(`/payments/${this.userId}`).update({
		          	billing: data['billing'],
		          	billing_cycle_anchor: data['billing_cycle_anchor'],
		          	cancel_at_period_end: data['cancel_at_period_end'],
		          	canceled_at: data['canceled_at'],
		          	created: data['created'],
		          	current_period_end: data['current_period_end'],
		          	current_period_start: data['current_period_start'],
		          	customer:data['customer'],
		          	id:data['id'],
		          	quantity: data['quantity'],
		          	start: data['start'],
		          	status: data['status'],
		          	tax_percent: data['tax_percent'],
		          	object: data['object'],
		          	amount: data['plan']['amount'],
		          	currency: data['plan']['currency'],
		          	nickname:data['plan']['nickname'],
		          	product:data['plan']['product'],
		          	eventtype: 'cancelnow',
		      	});
	      	}
	        //this.db.list(`/payments/${this.userId}`).push(data);
	        const user1 = {to:`${this.UEmail}`,Name:`${this.UName}`};
			const headers = new HttpHeaders()
	      		.set('Content-Type', 'application/json');
	      	this.http.post(`https://nodestripepayment.herokuapp.com/canclenowemail`, JSON.stringify(user1), {
		      	headers: headers
		    })
		    .subscribe(data => {
		    	console.log(data);
		    });
	        location.reload();
	    });
  	}
  	onCancelEnd(){
		const user = { id : `${this.SubsId}`};
  		const headers = new HttpHeaders()
          .set('Content-Type', 'application/json');
	    this.http.post(`https://nodestripepayment.herokuapp.com/cancleend`, JSON.stringify(user), {
	      headers: headers
	    })
	    .subscribe(data => {
	        console.log(data);
	        //this.db.list(`/payments/${this.userId}`).remove();
	        if(data['discount']){
	      		this.db.object(`/payments/${this.userId}`).update({
		          	billing: data['billing'],
		          	billing_cycle_anchor: data['billing_cycle_anchor'],
		          	cancel_at_period_end: data['cancel_at_period_end'],
		          	canceled_at: data['canceled_at'],
		          	created: data['created'],
		          	current_period_end: data['current_period_end'],
		          	current_period_start: data['current_period_start'],
		          	customer:data['customer'],
		          	id:data['id'],
		          	quantity: data['quantity'],
		          	start: data['start'],
		          	status: data['status'],
		          	tax_percent: data['tax_percent'],
		          	object: data['object'],
		          	amount: data['plan']['amount'],
		          	currency: data['plan']['currency'],
		          	nickname:data['plan']['nickname'],
		          	product:data['plan']['product'],
		          	couponid:data['discount']['coupon']['id'],
		          	percent_off:data['discount']['coupon']['percent_off'],
		          	eventtype: 'cancelend',
		      	});
	      	} else {
	      		this.db.object(`/payments/${this.userId}`).update({
		          	billing: data['billing'],
		          	billing_cycle_anchor: data['billing_cycle_anchor'],
		          	cancel_at_period_end: data['cancel_at_period_end'],
		          	canceled_at: data['canceled_at'],
		          	created: data['created'],
		          	current_period_end: data['current_period_end'],
		          	current_period_start: data['current_period_start'],
		          	customer:data['customer'],
		          	id:data['id'],
		          	quantity: data['quantity'],
		          	start: data['start'],
		          	status: data['status'],
		          	tax_percent: data['tax_percent'],
		          	object: data['object'],
		          	amount: data['plan']['amount'],
		          	currency: data['plan']['currency'],
		          	nickname:data['plan']['nickname'],
		          	product:data['plan']['product'],
		          	eventtype: 'cancelend',
		      	});
	      	}
	        //this.db.list(`/payments/${this.userId}`).push(data);
	        const user1 = {to:`${this.UEmail}`,Name:`${this.UName}`};
			const headers = new HttpHeaders()
	      		.set('Content-Type', 'application/json');
	      	this.http.post(`https://nodestripepayment.herokuapp.com/cancleendemail`, JSON.stringify(user1), {
		      	headers: headers
		    })
		    .subscribe(data => {
		    	console.log(data);
		    });
	        location.reload();
	    });
  	}
  	/*SubsEdit(event , SubId){
  		console.log(SubId);
		const user = { id : SubId};
  		const headers = new HttpHeaders()
          .set('Content-Type', 'application/json');
	    // ports:
	    // :3000 - to call nodejs server
	    // :3001 - to call aspnet core server
	    this.http.post(`https://nodestripepayment.herokuapp.com/subUpdate`, JSON.stringify(user), {
	      headers: headers
	    })
	    .subscribe(data => {
	        //console.log(data);
	        this.db.list(`/payments/${this.userId}`).remove();
	        //this.db.list(`/store/${this.userId}`).remove();
	        this.db.list(`/payments/${this.userId}`).push(data)
 			this.router.navigate(['/mysubscriptionsplan']);
 			location.reload();
	    });
  	}*/

  	/*logout() {
    	this.angularAuth.auth.signOut();
    	this.router.navigate(['/login']);
  	}*/
}
