import { Injectable } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";

import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';

@Injectable()
export class PaymentService {

  userId: string;
  membership: any;

  constructor(private db: AngularFireDatabase, private afAuth: AngularFireAuth) {
    this.afAuth.authState.subscribe((auth) => {
      if (auth) this.userId = auth.uid
    });
  }


   processPayment(token: any, amount: number, NumberOfStores: any) {
     const payment = { token, amount, NumberOfStores }
     return this.db.list(`/payments/${this.userId}`).push(payment)
   }

}
