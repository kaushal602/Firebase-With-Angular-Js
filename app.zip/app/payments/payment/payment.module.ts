import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SubscriptionsComponent } from '../../subscriptions/subscriptions.component';
import { PaymentService } from '../payment.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [
    PaymentService
  ]
})
export class PaymentModule { }
