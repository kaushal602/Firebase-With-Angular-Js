import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'firebase/storage';
import * as firebase from 'firebase/app';
import CryptoJS from 'crypto-js';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
 

export class ProfileComponent implements OnInit {
user1: any;
storId:any;
	authState: any;
	result: any = null;

	Storeresult: any[];
	values: any;
	uid: string;
	userName: string;
	email: string;
	phonenumber: string;
	Country: string;
	companyname: string;
	Address: string;
	pin: string;
	UsrSubscribe: string;
	PhotoURL: string;
	ProfileImage: string;
	CompanyImage: string;
	CompanyPhotoURL: string;
	selectedProfileFiles: FileList;
	selectedCompanyFiles: FileList;
	file: File;
	VatCheckbox: boolean;
	VatRegisteredNumber: string;
	ErrorMsg: any;
	country: any;
	countrylist: any;
	options: any[];
	storageRef: any;
	storageRef1: any;
	storageRef2: any;
	comlogo1: any;
	proimg: any;
	userId: string;
	vaterror: any;
	vatclass: any;

	UName: string;
	UPhoneNumber: string;
	UsrPassword: string;
	key: any;
    iv: any;
    plain_text: string;
    encrypted_text: string;
    payment_var: string;
  	decrypted_text: string;
  	encryptedName: string;
  	ActvPay: any;
  	userForm: FormGroup;
  	storarray = Array();
  	constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router,private http: HttpClient, private formBuilder: FormBuilder) {
  		this.angularAuth.authState.subscribe((auth) => {
            this.authState = auth
            if(auth) {
	            this.userId = auth.uid
	            console.log(auth);
		 
		        this.plain_text = '';
		      	this.payment_var = '';
		        this.encrypted_text = '';
		        this.decrypted_text = '';

	            this.user1 = this.db.object('/users/'+this.authState.uid).valueChanges();
	            this.user1.subscribe(res => {
		            this.result = res
		            var base64 = this.result.Name;
					var words = CryptoJS.enc.Base64.parse(base64);
					var textString = CryptoJS.enc.Utf8.stringify(words);
					this.UName = textString;

					var base64 = this.result.PhoneNumber;
					var words = CryptoJS.enc.Base64.parse(base64);
					var textString = CryptoJS.enc.Utf8.stringify(words);
					this.UPhoneNumber = textString;

					var base64 = this.result.Password;
					var words = CryptoJS.enc.Base64.parse(base64);
					var textString = CryptoJS.enc.Utf8.stringify(words);
					this.UsrPassword = textString;
					//console.log(this.UName);
					this.CompanyPhotoURL = res.CompanyImage
		            this.comlogo1 = this.result.PhotoURL;
					if(this.result.CompanyImage != null){
						this.storageRef1 = firebase.storage().ref().child('/companylogo/'+this.result.CompanyImage);
						this.storageRef1.getDownloadURL().then(companylogo => {
							this.comlogo1 = companylogo;
							//console.log(this.comlogo);
						});
					}
					console.log(this.comlogo1);
		        });
	            this.storId = this.db.list('/store/'+this.authState.uid).valueChanges();
		            this.storId.subscribe(res => {
		            this.Storeresult = res
		            console.log(this.Storeresult);
		            var j = 0;
		            //var storarray = Array();
		            res.forEach(function (value) {
					  console.log(value);
					  	this.storarray.push(value);
					  	console.log(value['subscriptions']);
					  	j++;
					});
					console.log(this.storarray);
			    });
		        this.user2 = this.db.object('/payments/'+this.authState.uid).valueChanges();
		            this.user2.subscribe(res => {
		            this.payment = res
		            if(res){
		            	if(this.payment.status == 'active'){
		            		this.ActvPay = 'Yes';
		            		this.CustomerId = '';
		            	} else{
		            		this.ActvPay = 'No';
		            		this.CustomerId = this.payment.customer;
		            	}
		            } else {
		            	this.ActvPay = 'No';
		            	this.CustomerId = '';
		            }
		            console.log(res);
		            console.log(res);
	    		});

		        let options=[];
		        this.country = this.db.object('/Countries').valueChanges();
			      this.country.subscribe(res => {
			        this.countrylist = res.Country
			        this.options = this.countrylist.split(',');
			        console.log(this.options);
			    });
		    } else {
		    	this.router.navigate(['/login']);
		    }
		});
	}
	isValidFormSubmitted: boolean = null;
	ngOnInit() {
		
		this.vatclass = '';
  		this.DeleteMessage = "This will remove your account and details from workbudi and you will need to register again to be able to access workbudi features in the future";
  		this.SubMessage = "";
  		this.erMsg = "";
  		this.userForm =this.formBuilder.group({
		//uid: new FormControl(''),
		    uname: new FormControl('', Validators.required),
		    email: new FormControl('', Validators.required),
		    phonenumber: new FormControl('', Validators.required),
		    companyname: new FormControl('', Validators.required),
		    Country: new FormControl('', Validators.required),
		   //Address: new FormControl('', Validators.required),
		    pin: new FormControl('', Validators.required),
	    	VatCheckbox: new FormControl(''),
	    	VatRegisteredNumber: new FormControl(''),
		    UsrSubscribe: new FormControl(''),
		    PhotoURL: new FormControl(''),
		   //ProfileImage: new FormControl(''),
		    CompanyImage: new FormControl(''),
		    CompanyPhotoURL: new FormControl(''),
		});
  	}
	cmimg: any;
	PhURL:any;
	selectCompanylogo(event: any){
		this.selectedCompanyFiles = event.target.files;
		if (event.target.files && event.target.files[0]) {
		    var reader = new FileReader();

		    reader.onload = (event:any) => {
		      this.cmimg = event.target.result;
		    }

		    reader.readAsDataURL(event.target.files[0]);
		}
		const file: File = event.target.files[0];
		if (file.type.match('image.*')) {
			console.log(file.name);
			const metaData = {'contentType': file.type};
			const uniqkey = 'company' + Math.floor(Math.random() * 1000000);
			const storeageRef: firebase.storage.Reference = firebase.storage().ref('/companylogo/'+ uniqkey+'-'+file.name);
			//const storeageRef: firebase.storage.Reference = firebase.storage().ref('/companylogo/'+file.name);
			storeageRef.put(file, metaData);
			this.CompanyImage = uniqkey+'-'+file.name;
			this.PhURL = uniqkey+'-'+file.name;
			console.log(this.PhotoURL);
			console.log("file uploading: ", file.name);
		} else {
	      alert('invalid format!');
	    }
	}
	
	isFieldValid(field: string) {
	    return !this.userForm.get(field).valid && this.userForm.get(field).touched;
	}

	displayFieldCss(field: string) {
	    return {
	      'has-error': this.isFieldValid(field),
	      'has-feedback': this.isFieldValid(field)
	    };
	}
    onFormSubmit() {
    	console.log(this.userForm.status)
	   //this.isValidFormSubmitted = false;
	   if(this.userForm.invalid){
		  //return;	
		  this.ErrorMsg = "Please enter requires fields.";
		  this.validateAllFormFields(this.userForm);
	   }
	   if(this.userForm.valid){
		   	this.isValidFormSubmitted = true;
		   	this.userName = this.userForm.get('uname').value;
           	var textString = this.userName; // Utf8-encoded string
			var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
			var base64 = CryptoJS.enc.Base64.stringify(words);
		   	this.encrypted_text = base64;

		   	this.email = this.userForm.get('email').value;
		   	var textString = this.email; // Utf8-encoded string
			var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
			var base64 = CryptoJS.enc.Base64.stringify(words);
		    this.email = base64;

		   	this.phonenumber = this.userForm.get('phonenumber').value;
		   	var textString = this.phonenumber; // Utf8-encoded string
			var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
			var base64 = CryptoJS.enc.Base64.stringify(words);
		    this.phonenumber = base64;

		   this.companyname = this.userForm.get('companyname').value;
		   this.Country = this.userForm.get('Country').value;
		   //this.Address = this.userForm.get('Address').value;
		   this.pin = this.userForm.get('pin').value;
		   this.UsrSubscribe = this.userForm.get('UsrSubscribe').value;
		   this.PhotoURL = this.userForm.get('PhotoURL').value;
		   //this.ProfileImage = this.userForm.get('ProfileImage').value;
		   this.CompanyImage = this.userForm.get('CompanyImage').value;
		   this.CompanyPhotoURL = this.userForm.get('CompanyPhotoURL').value;
		   this.VatCheckbox = this.userForm.get('VatCheckbox').value;
		   console.log(this.VatCheckbox);
		   this.VatRegisteredNumber = this.userForm.get('VatRegisteredNumber').value;
	   		if(this.VatCheckbox != null && this.VatCheckbox != false) {
				    if(this.VatRegisteredNumber == null || this.VatRegisteredNumber == ''){
			    		console.log(this.VatRegisteredNumber);
            			this.vaterror = "Please Enter VAT Number";
            			this.vatclass = "vatreq";
            			console.log(123);
            			console.log(this.VatCheckbox);
            		} else {
        			if(this.selectedCompanyFiles){
						//const storageRef2: firebase.storage.Reference = firebase.storage().ref();
			    		//storageRef2.child('companylogo/'+this.PhotoURL).delete();
			    			this.CompanyImage = `${this.PhURL}`;
							this.PhotoURL = `${this.PhURL}`;
					}
					this.VatCheckbox = true;
				    this.db.object(`/users/${this.userId}`).update({
			            Name: this.encrypted_text,
			          	Email:  this.email,
			            PhoneNumber: this.phonenumber,
			            CompanyName: this.companyname,
			            CountryName: this.Country,
			          //Address: this.Address,
			            pin: this.pin,
			            PhotoURL: this.PhotoURL,
			            Subscribe:this.UsrSubscribe,
						VatRegisteredNumber:this.VatRegisteredNumber,
						VatCheckbox:this.VatCheckbox,
						//CompanyPhotoURL: this.PhotoURL,
				      //ProfileImage: this.ProfileImage,
				        CompanyImage: this.CompanyImage,
			        });
				   console.log(this.CompanyPhotoURL);
				   this.ErrorMsg = "";
				    location.reload();
        		}
            } else {
				if(this.selectedCompanyFiles){
					//const storageRef2: firebase.storage.Reference = firebase.storage().ref();
		    		//storageRef2.child('companylogo/'+this.PhotoURL).delete();
		    		//alert('companylogo/'+this.CompanyPhotoURL);
					this.CompanyImage = `${this.PhURL}`;
					this.PhotoURL = `${this.PhURL}`;
				}
				console.log('Encrypted value :' + this.encrypted_text);
			    this.db.object(`/users/${this.userId}`).update({
		            Name: this.encrypted_text,
		          	Email:  this.email,
		            PhoneNumber: this.phonenumber,
		            CompanyName: this.companyname,
		            CountryName: this.Country,
		          //Address: this.Address,
		            pin: this.pin,
		            PhotoURL: this.PhotoURL,
		            Subscribe:this.UsrSubscribe,
					VatRegisteredNumber:this.VatRegisteredNumber,
					VatCheckbox:this.VatCheckbox,
			      //ProfileImage: this.ProfileImage,
			        CompanyImage: this.CompanyImage,
		        });
			   console.log(this.CompanyPhotoURL);
			   this.ErrorMsg = "";
			    location.reload();
			}
		}
	}
	validateAllFormFields(formGroup: FormGroup) {
	    Object.keys(formGroup.controls).forEach(field => {
	      console.log(field);
	      const control = formGroup.get(field);
	      if (control instanceof FormControl) {
	        control.markAsTouched({ onlySelf: true });
	      } else if (control instanceof FormGroup) {
	        this.validateAllFormFields(control);
	      }
	    });
	}
	
	display='none';
	onCloseHandled(){
       this.display='none'; 
    }
	DeleteUser(){
		this.display='block';
	}
	user2: any;
	payment: any;
	DeleteMessage: any;
	SubMessage: any;
	erMsg: any;
	CustomerId:any;
	curId:any;
	urid:any;
	//recentlogin:any;
	onconfirm(){
		var user = firebase.auth().currentUser;
		var urid = '';
		console.log(user);
		console.log(user.providerData);
		console.log(user.providerData[0].providerId);
		var recentlogin = 0;
		this.payment = `${this.ActvPay}`;
		this.curId = `${this.CustomerId}`;
        if(this.payment == 'Yes'){
        	this.DeleteMessage = "";
        	this.SubMessage ="To remove your account you must first cancel your subscription and you will be able to remove once the subscription has ended. Any question then please contact workbudi";
        } else if(this.curId != '') {
        	console.log(this.curId);
        	this.display='none';
        	//console.log(user);
        	const user1 = { id : this.curId};
		  		const headers = new HttpHeaders()
		          .set('Content-Type', 'application/json');
			    this.http.post(`https://nodestripepayment.herokuapp.com/customerdelete`, JSON.stringify(user1), {
			      headers: headers
			    })
			    .subscribe(data => {
			        console.log(data);
			        if(data['deleted'] == true){
			        	
				        firebase.database().ref("payments").child(user.uid).remove();
				        for (var j = 0; j < this.Storeresult.length; j++) {
			        		console.log(this.Storeresult[j].StorKey);
			        		console.log(this.Storeresult[j]);
			        		firebase.database().ref('/locations/'+this.Storeresult[j].StorKey).remove();
			        	}
				        //firebase.database().ref("store").child(user.uid).remove();
				        //firebase.database().ref("advertising").child(user.uid).remove();
			        	//firebase.database().ref("users").child(user.uid).remove();
			        	//var user = firebase.auth().currentUser;
			        	if(user.providerData[0].providerId=='google.com'){
			        		var provider = new firebase.auth.GoogleAuthProvider();
							provider.addScope('email');
							provider.addScope('profile');
							user.reauthenticateWithPopup(provider).then(function(result) {
							  	var googleuser = result.user;
							  	var credential = result.credential;
							  	
							  	user.delete().then(function() {
								  	firebase.database().ref("store").child(googleuser.uid).remove();
								    firebase.database().ref("advertising").child(googleuser.uid).remove();
					        		firebase.database().ref("users").child(googleuser.uid).remove();
							    }).catch(function(error) {
									window.location.href = "https://nodestripepayment.herokuapp.com/login";
									console.log('sub with delete');
								});
							}, function(error) {
								console.log(error);
							});
				   //      	user.delete().then(function() {
							// }).catch(function(error) {
							// 	window.location.href = "https://nodestripepayment.herokuapp.com/login";
							// 	console.log('sub with delete');
							// });
						} else if( user.providerData[0].providerId=='facebook.com') {
							for (var j = 0; j < this.Storeresult.length; j++) {
				        		console.log(this.Storeresult[j].StorKey);
				        		console.log(this.Storeresult[j]);
				        		firebase.database().ref('/locations/'+this.Storeresult[j].StorKey).remove();
				        	}
							var provider = new firebase.auth.FacebookAuthProvider();
							provider.addScope('email');
							provider.addScope('user_friends');
							
								user.reauthenticateWithPopup(provider).then(function(result) {
									
								  	var fbuser = result.user;
								  	var credential = result.credential;
								  	user.delete().then(function() {
										  	firebase.database().ref("store").child(fbuser.uid).remove();
										    firebase.database().ref("advertising").child(fbuser.uid).remove();
							        		firebase.database().ref("users").child(fbuser.uid).remove();
							        }).catch(function(error) {
										window.location.href = "https://nodestripepayment.herokuapp.com/login";
										console.log('sub with delete');
									});
								}, function(error) {
									console.log(error);
								});
							
							// user.delete().then(function() {
							// }).catch(function(error) {
							// 	window.location.href = "https://nodestripepayment.herokuapp.com/login";
							// 	console.log('sub with delete');
							// });
						} else {
							for (var j = 0; j < this.Storeresult.length; j++) {
				        		console.log(this.Storeresult[j].StorKey);
				        		console.log(this.Storeresult[j]);
				        		firebase.database().ref('/locations/'+this.Storeresult[j].StorKey).remove();
				        	}
							var pass =  `${this.UsrPassword}`;
							var credential = firebase.auth.EmailAuthProvider.credential(
							    user.email, 
							    pass
							);
							user.reauthenticateAndRetrieveDataWithCredential(credential).then(function() {
								
								user.delete().then(function() {
					        		firebase.database().ref("users").child(user.uid).remove();
					        		firebase.database().ref("store").child(user.uid).remove();
									firebase.database().ref("advertising").child(user.uid).remove();
					        		console.log('delete with subscrib');
								}).catch(function(error) {
									window.location.href = "https://nodestripepayment.herokuapp.com/login";
									console.log('sub with delete');
								});
							}).catch(function(error) {
							  console.log(error);
							});
						}

			        	/*user.delete().then(function() {
			        		firebase.database().ref("users").child(user.uid).remove();
			        		console.log('delete with subscrib');
						}).catch(function(error) {
							console.log(error);
							firebase.auth().signOut()
							window.location.href = "https://nodestripepayment.herokuapp.com/login";
							console.log('sub with delete');
						});*/
			        }
			    });
		} else {
			if(user.providerData[0].providerId=='google.com'){
				console.log(this.Storeresult);
				for (var j = 0; j < this.Storeresult.length; j++) {
	        		console.log(this.Storeresult[j].StorKey);
	        		console.log(this.Storeresult[j]);
	        		firebase.database().ref('/locations/'+this.Storeresult[j].StorKey).remove();
	        	}
				var provider = new firebase.auth.GoogleAuthProvider();
				provider.addScope('email');
				provider.addScope('profile');
				user.reauthenticateWithPopup(provider).then(function(result) {
				  	var googleuser = result.user;
				  	console.log(googleuser)
				  	console.log(googleuser.uid);
				  	var credential = result.credential;

				  	
				  	user.delete().then(function() {
				  		
					  	firebase.database().ref("store").child(googleuser.uid).remove();
					    firebase.database().ref("advertising").child(googleuser.uid).remove();
		        		firebase.database().ref("users").child(googleuser.uid).remove();
		        		
				    }).catch(function(error) {
						window.location.href = "https://nodestripepayment.herokuapp.com/login";
						console.log('sub with delete');
					});
				}, function(error) {
					console.log(error);
				});
			} else if(user.providerData[0].providerId=='facebook.com') {
				for (var j = 0; j < this.Storeresult.length; j++) {
	        		console.log(this.Storeresult[j].StorKey);
	        		console.log(this.Storeresult[j]);
	        		firebase.database().ref('/locations/'+this.Storeresult[j].StorKey).remove();
	        	}
				var provider = new firebase.auth.FacebookAuthProvider();
				provider.addScope('email');
				provider.addScope('user_friends');
				user.reauthenticateWithPopup(provider).then(function(result) {
				  	var fbuser = result.user;
				  	var credential = result.credential;
				  	
				  	user.delete().then(function() {
					  	firebase.database().ref("store").child(fbuser.uid).remove();
					    firebase.database().ref("advertising").child(fbuser.uid).remove();
		        		firebase.database().ref("users").child(fbuser.uid).remove();
	        		}).catch(function(error) {
						window.location.href = "https://nodestripepayment.herokuapp.com/login";
						console.log('sub with delete');
					});
				}, function(error) {
					console.log(error);
				});
				// user.delete().then(function() {
				// 	firebase.database().ref("store").child(user.uid).remove();
				//     firebase.database().ref("advertising").child(user.uid).remove();
	   //      		firebase.database().ref("users").child(user.uid).remove();
	   //      		console.log('delete with facebook subscrib');
				// }).catch(function(error) {
				// 	window.location.href = "https://nodestripepayment.herokuapp.com/login";
				// 	console.log('sub with delete');
				// });
			} else {
				console.log('123');
				for (var j = 0; j < this.Storeresult.length; j++) {
	        		console.log(this.Storeresult[j].StorKey);
	        		console.log(this.Storeresult[j]);
	        		firebase.database().ref('/locations/'+this.Storeresult[j].StorKey).remove();
	        	}
				var pass =  `${this.UsrPassword}`;
				var credential = firebase.auth.EmailAuthProvider.credential(
				    user.email, 
				    pass
				);
				user.reauthenticateAndRetrieveDataWithCredential(credential).then(function() {
					
					user.delete().then(function() {
						firebase.database().ref("store").child(user.uid).remove();
					    firebase.database().ref("advertising").child(user.uid).remove();
		        		firebase.database().ref("users").child(user.uid).remove();
		        		console.log('delete with email subscrib');
					}).catch(function(error) {
						window.location.href = "https://nodestripepayment.herokuapp.com/login";
						console.log('sub with delete');
					});
				}).catch(function(error) {
				  console.log(error);
				});
			}

			/*user.delete().then(function() {
				firebase.database().ref("users").child(user.uid).remove();
				console.log('delete');
			}).catch(function(error) {
				console.log(error);
				firebase.auth().signOut();
				window.location.href = "https://nodestripepayment.herokuapp.com/login";
				//alert("To delete a user, the user must have signed in recently.")
			});*/
		}
            	
            
	}
	/*DeleteUser(){
		var user = firebase.auth().currentUser;
	
		user.delete().then(function() {
		});
		this.router.navigate(['/login']);
	}*/

  	
  	


}
