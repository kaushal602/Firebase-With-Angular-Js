import { Component, OnInit, NgZone } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'firebase/storage';
import * as firebase from 'firebase/app';
import * as Stripe from 'stripe';
import CryptoJS from 'crypto-js';

/*export interface FormModel {
  captcha?: string;
}*/


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
	uid: string;
	userName: string;
	email: string;
	email2: string;
	conemail: string;
	phonenumber: string;
	Country: string;
	companyname: string;
	Address: string;
	pin: string;
	PhotoURL: string;
	password: string;
	cpassword: string;
	Subscribe: string;
	ProfileImage: string;
	CompanyImage: string;
	termsconditions: string;
	//file: any;
	selectedProfileFiles: FileList;
	selectedCompanyFiles: FileList;
	file: File;
	VatCheckbox: boolean;
	VatRegisteredNumber: string;

	ErrorMsg: any;

captcha?: string;
captchaPassed: boolean = false;
captchaResponse: string;

	UName: string;
	UPhoneNumber: string;

	authState: any;
	userId: string;
	vaterror: any;
	vatclass: any;

	options: any[];
	country: any;
	countrylist: any;
	userForm: FormGroup;
  constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router,private http: HttpClient, private zone: NgZone, private formBuilder: FormBuilder) {
  	this.angularAuth.authState.subscribe((auth) => {
        this.authState = auth
        if(auth) {
        	this.userId = auth.uid
        	//this.router.navigate(['/advertising']);
        	
	    } else {
	    	//this.router.navigate(['/login']);
	    }
	    let options=[];
	    this.countrylist = countrylist();
	    this.options = this.countrylist.split(',');
     //    this.country = this.db.object('/Countries').valueChanges();
     //    this.country.subscribe(res => {
	    //     this.countrylist = res.Country
	    //     this.options = this.countrylist.split(',');
	    //     console.log(this.options);
	    // });
	});
  }
private isValidFormSubmitted: boolean;
ngOnInit() {
	this.captchaResponse = '';
	this.vatclass = '';
	this.userForm = this.formBuilder.group({
		//uid: new FormControl(null),
	   uname: new FormControl(null, Validators.required),
	   email: new FormControl(null, Validators.required),
	   conemail: new FormControl('', Validators.required),
	   password: new FormControl(null, Validators.required),
	   cpassword: new FormControl(null, Validators.required),
	   phonenumber: new FormControl(null, Validators.required),
	   companyname: new FormControl(null, Validators.required),
	   Country: new FormControl(null, Validators.required),
	   //Address: new FormControl(null, Validators.required),
	   pin: new FormControl(null,Validators.required),
	   VatCheckbox: new FormControl(null),
	   VatRegisteredNumber: new FormControl(null),
	   Subscribe: new FormControl(null),
	   termsconditions: new FormControl(null, Validators.required),
	   //ProfileImage: new FormControl(null, Validators.required),
	   CompanyImage: new FormControl(null, Validators.required),
	   //captcha: new FormControl(null, Validators.required),
	});
  }

	isFieldValid(field: string) {
	    return !this.userForm.get(field).valid && this.userForm.get(field).touched;
	  }

	  displayFieldCss(field: string) {
	    return {
	      'has-error': this.isFieldValid(field),
	      'has-feedback': this.isFieldValid(field)
	    };
	  }

captchaResolved(response: string): void {
    this.zone.run(() => {
        this.captchaPassed = true;
        this.captchaResponse = response;
    });
	console.log(this.captchaResponse);
}

	
	cmimg: any;
	selectCompanylogo(event: any){
		this.selectedCompanyFiles = event.target.files;
		//this.selectedCompanyFiles = event.target.files;
		if (event.target.files && event.target.files[0]) {
		    var reader = new FileReader();

		    reader.onload = (event:any) => {
		      this.cmimg = event.target.result;
		    }

		    reader.readAsDataURL(event.target.files[0]);
		}
		const file: File = event.target.files[0];
		if (file.type.match('image.*')) {
			console.log(file.name);
			const metaData = {'contentType': file.type};
			const uniqkey = 'company' + Math.floor(Math.random() * 1000000);
			const storeageRef: firebase.storage.Reference = firebase.storage().ref('/companylogo/'+ uniqkey+'-'+file.name);
			//const storeageRef: firebase.storage.Reference = firebase.storage().ref('/companylogo/'+file.name);
			storeageRef.put(file, metaData);
			this.CompanyImage = uniqkey+'-'+file.name;
			this.PhotoURL = uniqkey+'-'+file.name;
			console.log("file uploading: ", file.name);
		} else {
	      alert('invalid format!');
	    }
	    /*if (file.type.match('image.*')) {
			console.log(file.name);
			const metaData = {'contentType': file.type};
			const uniqkey1 = 'company' + Math.floor(Math.random() * 1000000);
			const storeageRef: firebase.storage.Reference = firebase.storage().ref('/companylogo/'+file.name);
			storeageRef.put(file, metaData);
			console.log("file uploading: ", file.name);
		} else {
	      alert('invalid format!');
	    }*/
	}
//public formModel: FormModel = {};
	
	
	/*isFieldValid(field: string) {
	    return !this.userForm.get(field).valid && this.userForm.get(field).touched;
	}
	displayFieldCss(field: string) {
	    return {
	      'has-error': this.isFieldValid(field),
	      'has-feedback': this.isFieldValid(field)
	    };
	}*/
	password1:any;
    onFormSubmit() {
    	console.log(this.userForm.status)
	   //this.isValidFormSubmitted = false;
	   if(this.userForm.invalid){
	   		this.ErrorMsg = "Please enter requires fields.";
	   		this.validateAllFormFields(this.userForm);
		  //return;	
	   } 
	   if(this.userForm.valid){
		   //this.isValidFormSubmitted = true;
		   //this.uid = this.userForm.get('uid').value;
		   this.userName = this.userForm.get('uname').value;
		   var textString = this.userName; // Utf8-encoded string
			var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
			var base64 = CryptoJS.enc.Base64.stringify(words);
		   	this.userName = base64;

		   this.email = this.userForm.get('email').value;
		   this.email2 = this.userForm.get('email').value;
		   
		   this.conemail = this.userForm.get('conemail').value;
		   this.password = this.userForm.get('password').value;
		   this.cpassword = this.userForm.get('cpassword').value;
		   var textString = this.password; // Utf8-encoded string
			var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
			var base64 = CryptoJS.enc.Base64.stringify(words);
		   	this.password1 = base64;

		   this.phonenumber = this.userForm.get('phonenumber').value;
		   	var textString = this.phonenumber; // Utf8-encoded string
			var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
			var base64 = CryptoJS.enc.Base64.stringify(words);
		    this.phonenumber = base64;

		   this.companyname = this.userForm.get('companyname').value;
		   this.Country = this.userForm.get('Country').value;
		   //this.Address = this.userForm.get('Address').value;
		   this.pin = this.userForm.get('pin').value;
		   this.Subscribe = this.userForm.get('Subscribe').value;
		   this.termsconditions = this.userForm.get('termsconditions').value;
		  //this.ProfileImage = this.userForm.get('ProfileImage').value;
		   //this.CompanyImage = this.userForm.get('CompanyImage').value;
		   this.VatCheckbox = this.userForm.get('VatCheckbox').value;
		   this.VatRegisteredNumber = this.userForm.get('VatRegisteredNumber').value;
		  
		   var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if(re.test(this.email)){
            	if(this.email == this.conemail) {
            		if(this.password == this.cpassword) {
	            		var textString = this.email; // Utf8-encoded string
						var words = CryptoJS.enc.Utf8.parse(textString); // WordArray object
						var base64 = CryptoJS.enc.Base64.stringify(words);
					    this.email = base64;
					    if(this.captchaResponse != ''){
						    if(this.VatCheckbox != null && this.VatCheckbox != false) {
						    	if(this.VatRegisteredNumber == null){
			            			this.vaterror = "Please Enter VAT Number";
			            			this.vatclass = "vatreq";
			            			console.log(123);
			            			console.log(this.VatCheckbox);
			            		} else {
			            			
									this.CompanyImage = `${this.PhotoURL}`;
									this.PhotoURL = `${this.PhotoURL}`;
								    this.angularAuth.auth.createUserWithEmailAndPassword(this.email2, this.password).then((user) => {

									   this.db.object('/users/'+user.uid).set({
								          Name: this.userName,
								          Email: this.email,
								          Password: this.password1,
								          PhoneNumber: this.phonenumber,
								          CompanyName: this.companyname,
								          CountryName: this.Country,
								          pin: this.pin,
								          PhotoURL: this.PhotoURL,
								          Subscribe:this.Subscribe,
											TermCondition:this.termsconditions,
									      VatRegisteredNumber:this.VatRegisteredNumber,
									      VatCheckbox:true,
								          //ProfileImage: uniqkey+'-'+file.name,
								          CompanyImage: this.PhotoURL,
								      });
									   //this.router.navigate(['/mysubscriptionsplan']);
									   	const emailaddress = { email : this.email2};
						                const headers = new HttpHeaders()
						                    .set('Content-Type', 'application/json');
						                this.http.post(`https://nodestripepayment.herokuapp.com/subscription`, JSON.stringify(emailaddress), {
						                  headers: headers
						                })
						                .subscribe(data => {
						                  console.log(data);
						                });
									   window.location.href = "https://nodestripepayment.herokuapp.com/mysubscriptionsplan";
									   	console.log(this.email);
								   		console.log(this.userName);
									}).catch(function(error) {
										alert(error.message);
										console.log(error); 
									});
			            		}
		            		} else {
							    console.log(this.captchaResponse);
		            			this.vaterror = "";
		            			this.vatclass = "";
		            			console.log('file');
		            			console.log(this.selectedCompanyFiles)
								
								this.CompanyImage = `${this.PhotoURL}`;
								this.PhotoURL = `${this.PhotoURL}`;
							    this.angularAuth.auth.createUserWithEmailAndPassword(this.email2, this.password).then((user) => {

								   this.db.object('/users/'+user.uid).set({
							          Name: this.userName,
							          Email: this.email,
								       Password: this.password1,
							          PhoneNumber: this.phonenumber,
							          CompanyName: this.companyname,
							          CountryName: this.Country,
							          //Address: this.Address,
							          pin: this.pin,
							          PhotoURL: this.PhotoURL,
							          Subscribe:this.Subscribe,
									TermCondition:this.termsconditions,
								      VatRegisteredNumber:this.VatRegisteredNumber,
								      VatCheckbox:this.VatCheckbox,
							          //ProfileImage: uniqkey+'-'+file.name,
							          CompanyImage: this.CompanyImage,
							      });
								   	const emailaddress = { email : this.email2};
					                const headers = new HttpHeaders()
					                    .set('Content-Type', 'application/json');
					                this.http.post(`https://nodestripepayment.herokuapp.com/subscription`, JSON.stringify(emailaddress), {
					                  headers: headers
					                })
					                .subscribe(data => {
					                  console.log(data);
					                });
								   this.router.navigate(['/mysubscriptionsplan']);
								   	console.log(this.email);
							   		console.log(this.userName);
								}).catch(function(error) {
									alert(error.message);
									console.log(error); 
								});
							}
						} else {
					    	this.ErrorMsg = "Captcha must be filled out";
					    }
					} else {
					    this.ErrorMsg = "Password and Confirm Password does not match.";
					}
				} else {
				    this.ErrorMsg = "Email address does not match";
				}
			} else {
					this.ErrorMsg = "Enter valid email address";
			}
		   
		}
	}

	validateAllFormFields(formGroup: FormGroup) {
	    Object.keys(formGroup.controls).forEach(field => {
	      console.log(field);
	      const control = formGroup.get(field);
	      if (control instanceof FormControl) {
	        control.markAsTouched({ onlySelf: true });
	      } else if (control instanceof FormGroup) {
	        this.validateAllFormFields(control);
	      }
	    });
	}
  /*ngOnInit() {
  }*/
  /*checkaddress(){
  	const user = { text : '1600 Amphitheatre Parkway, Mountain View, CA'};
	const headers = new HttpHeaders()
      .set('Content-Type', 'application/json');
    this.http.post(`https://nodestripepayment.herokuapp.com/getaddress`, JSON.stringify(user), {
      headers: headers
    })
    .subscribe(data => {
      console.log(data);
      const payment = { data }
      	console.log(data['status']);
      	console.log(data['text']);
      	var contact = JSON.parse(data['text']);

		console.log(contact['status']);
    });
  }*/
}
export function countrylist(){
	var countrylist = 'Afghanistan,Åland Islands,Albania,Algeria,American Samoa,Andorra,Angola,Anguilla,Antarctica,Antigua & Barbuda,Argentina,Armenia,Aruba,Ascension Island,Australia,Austria,Azerbaijan,Bahamas,Bahrain,Bangladesh,Barbados,Belarus,Belgium,Belize,Benin,Bermuda,Bhutan,Bolivia,Bosnia & Herzegovina,Botswana,Brazil,British Indian Ocean Territory,British Virgin Islands,Brunei,Bulgaria,Burkina Faso,Burundi,Cambodia,Cameroon,Canada,Canary Islands,Cape Verde,Caribbean Netherlands,Cayman Islands,Central African Republic,Ceuta & Melilla,Chad,Chile,China,Christmas Island,Cocos (Keeling) Islands,Colombia,Comoros,Congo - Brazzaville,Congo - Kinshasa,Cook Islands,Costa Rica,Côte d’Ivoire,Croatia,Cuba,Curaçao,Cyprus,Czechia,Denmark,Diego Garcia,Djibouti,Dominica,Dominican Republic,Ecuador,Egypt,El Salvador,Equatorial Guinea,Eritrea,Estonia,Ethiopia,Falkland Islands,Faroe Islands,Fiji,Finland,France,French Guiana,French Polynesia,French Southern Territories,Gabon,Gambia,Georgia,Germany,Ghana,Gibraltar,Greece,Greenland,Grenada,Guadeloupe,Guam,Guatemala,Guernsey,Guinea,Guinea-Bissau,Guyana,Haiti,Honduras,Hong Kong SAR China,Hungary,Iceland,India,Indonesia,Iran,Iraq,Ireland,Isle of Man,Israel,Italy,Jamaica,Japan,Jersey,Jordan,Kazakhstan,Kenya,Kiribati,Kosovo,Kuwait,Kyrgyzstan,Laos,Latvia,Lebanon,Lesotho,Liberia,Libya,Liechtenstein,Lithuania,Luxembourg,Macau SAR China,Macedonia,Madagascar,Malawi,Malaysia,Maldives,Mali,Malta,Marshall Islands,Martinique,Mauritania,Mauritius,Mayotte,Mexico,Micronesia,Moldova,Monaco,Mongolia,Montenegro,Montserrat,Morocco,Mozambique,Myanmar (Burma),Namibia,Nauru,Nepal,Netherlands,New Caledonia,New Zealand,Nicaragua,Niger,Nigeria,Niue,Norfolk Island,North Korea,Northern Mariana Islands,Norway,Oman,Pakistan,Palau,Palestinian Territories,Panama,Papua New Guinea,Paraguay,Peru,Philippines,Pitcairn Islands,Poland,Portugal,Puerto Rico,Qatar,Réunion,Romania,Russia,Rwanda,Samoa,San Marino,São Tomé & Príncipe,Saudi Arabia,Senegal,Serbia,Seychelles,Sierra Leone,Singapore,Sint Maarten,Slovakia,Slovenia,Solomon Islands,Somalia,South Africa,South Georgia & South Sandwich Islands,South Korea,South Sudan,Spain,Sri Lanka,St Barthélemy,St Helena,St Kitts & Nevis,St Lucia,St Martin,St Pierre & Miquelon,St Vincent & Grenadines,Sudan,Suriname,Svalbard & Jan Mayen,Swaziland,Sweden,Switzerland,Syria,Taiwan,Tajikistan,Tanzania,Thailand,Timor-Leste,Togo,Tokelau,Tonga,Trinidad & Tobago,Tristan da Cunha,Tunisia,Turkey,Turkmenistan,Turks & Caicos Islands,Tuvalu,Uganda,Ukraine,United Arab Emirates,United Kingdom,United States,Uruguay,US Outlying Islands,US Virgin Islands,Uzbekistan,Vanuatu,Vatican City,Venezuela,Vietnam,Wallis & Futuna,Western Sahara,Yemen,Zambia,Zimbabw';
	return countrylist;
}