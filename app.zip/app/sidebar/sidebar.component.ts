import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'firebase/storage';
import * as firebase from 'firebase/app';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
user1: any;
	authState: any;
	result: any = null;
	values: any;
	uid: string;
	userName: string;
	email: string;
	phonenumber: string;
	Country: string;
	companyname: string;
	Address: string;
	pin: string;
	UsrSubscribe: string;
	PhotoURL: string;
	ProfileImage: string;
	CompanyImage: string;
	selectedProfileFiles: FileList;
	selectedCompanyFiles: FileList;
	file: File;
	nodata: any;
	storageRef: any;
	storageRef1: any;
	storageRef2: any;
	comlogo: any;
	proimg: any;
  constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router) {
  		this.angularAuth.authState.subscribe((auth) => {
  			if(auth){
	            this.authState = auth
		            this.user1 = this.db.object('/users/'+this.authState.uid).valueChanges();
		            this.user1.subscribe(res => {
			            this.result = res
			            if(this.result.CompanyName != null && this.result.CountryName != null && this.result.Email != null && this.result.Name != null && this.result.PhoneNumber != null && this.result.pin != null && this.result.TermCondition != null && this.result.TermCondition == true ){
			            	this.nodata = "alldata";
		        			//this.router.navigate(['/advertising']);
			            } else {
			            	this.nodata = "noalldata";
			            	this.router.navigate(['/userregistration']);
			            }
						//console.log(this.proimg);
						//console.log(this.result.CompanyImage);
						this.comlogo = this.result.PhotoURL;
						if(this.result.CompanyImage != null || this.result.CompanyImage != ''){
							this.storageRef1 = firebase.storage().ref().child('/companylogo/'+this.result.CompanyImage);
							this.storageRef1.getDownloadURL().then(companylogo => {
								console.log(companylogo);
								if(companylogo){
									this.comlogo = companylogo;
								}
							});
							/*this.storageRef1.getDownloadURL().then(function(url) {
					          this.comlogo = url;
					        }).catch(function(error) {
					        });*/
						}
						console.log('k');
						console.log(this.comlogo);
						console.log('q');
			        });

	        }
		});
	}

  ngOnInit() {
  }
  logout() {
    	this.angularAuth.auth.signOut();
    	this.router.navigate(['/login']);
  	}
}
