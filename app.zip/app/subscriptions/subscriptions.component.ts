import { Component, OnInit, HostListener, AfterViewInit, OnDestroy, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { AngularFireAuth } from 'angularfire2/auth';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { FirebaseListObservable } from "angularfire2/database-deprecated";
import { AngularFirestore } from 'angularfire2/firestore';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { PaymentService } from '../payments/payment.service';
import { environment } from '../../environments/environment';
import 'firebase/storage';
import * as firebase from 'firebase/app';
import * as Stripe from 'stripe';
import { Message } from './message.model';
import CryptoJS from 'crypto-js';
//import { GeoService } from '../geo.service'

import * as GeoFire from "geofire";

@Component({
  selector: 'app-subscriptions',
  templateUrl: './subscriptions.component.html',
  styleUrls: ['./subscriptions.component.css']
})
export class SubscriptionsComponent implements OnInit {
//@ViewChild('cardInfo') cardInfo: ElementRef;
	
	userForm: FormGroup;
	paymentForm: FormGroup;

  card: any;
  //cardHandler = this.onChange.bind(this);

	uid: string;
	StoreName: string;
	email: string;
	Website: string;
	Country: string;
	PhoneNumber: string;
	Address: string;
	StorKey: string;

	urid: string;
	NumberOfStores: string;
	MonthlyPlan: string;

	handler: any;
  	amount = 5;

  	CouponCode: string;

	authState: any;
	user1: any;
	result: any[];
	values: any;
	userId: string;
	error: any;
	success: any;
  	payment:any;
	options: any[];
	user2: any;
	nopaymentclass: any;
	user: any;
	setingres: any;
	country: any;
	countrylist: any;
	countoptions: any[];
	totalstor: any;
	totalstor1: any;

	ValidAddress: any;
	UpdateValidAddress: any;

	BusinessCountry: any;
	busisCoun: string;
	CountryName: any;
	usercountry: string;
	taxrate: any;
	inputEl: ElementRef;
  	valueOnBlur: string;

  	latitude: number;
  	longitude: number;
  	addressinfo: string;
  	AddressLongitude: string;
  	AddressLatitude: string;
  	UserDetails: any;
  	UName: string;
	UEmail: string;
	tax_percent: string;
	BusinessPin:any;
	busisPin:any;
	markimage:any;
	SubsId:any;
  	CustomerId: any='';

  	dbRef: any;
  	geoFire: any;

  constructor(public angularAuth: AngularFireAuth,public db: AngularFireDatabase,private router: Router,private paymentSvc: PaymentService,private http: HttpClient, private cd: ChangeDetectorRef, private formBuilder: FormBuilder) { 
  	this.angularAuth.authState.subscribe((auth) => {
        this.authState = auth
        if (auth) this.userId = auth.uid
        if(auth) {
        	this.userId = auth.uid
        	let options=[];
	        this.user1 = this.db.list('/store/'+this.authState.uid).valueChanges();
	            this.user1.subscribe(res => {
	            this.result = res
	            this.totalstor = res.length;
	            this.totalstor1 = res.length;
	            for (var i = 1; i <= res.length; i++) {
	            	 var obj = i;
	            	options.push(obj);
			    }
			    this.options = options;
		    });
	        this.user = this.db.object('/setting').valueChanges();
		      this.user.subscribe(res => {
		        this.setingres = res
		        //console.log(this.setingres);
		    });
		    this.BusinessCountry = this.db.object('/users/'+this.authState.uid+'/CountryName').valueChanges();
		      this.BusinessCountry.subscribe(res => {
		        this.busisCoun = res
		        if(this.busisCoun != 'United Kingdom'){
		        	this.taxrate = 0;
		        } else {
		        	this.taxrate = 20;
		        }
		        console.log(this.taxrate);
		    });
		    this.BusinessPin = this.db.object('/users/'+this.authState.uid+'/pin').valueChanges();
		      	this.BusinessPin.subscribe(res => {
		      	this.busisPin = res
		      	if(this.busisPin=='Co-working Office'){
		      		this.markimage = 'assets/baseline_business.png';
		      	} else if(this.busisPin=='Gym'){
		      		this.markimage = 'assets/baseline_fitness_center.png';
		      	} else if(this.busisPin=='Restaurant'){
		      		this.markimage = 'assets/baseline_restaurant.png';
		      	} else if(this.busisPin=='Cafe') {
		      		this.markimage = 'assets/baseline_free_breakfast.png';
		      	} else {
		      		this.markimage = 'assets/map-marker-icon.png';
		      	}
		    });
		    this.UserDetails = this.db.object('/users/'+this.authState.uid).valueChanges();
		      this.UserDetails.subscribe(res => {
		        //this.UserDetails = res
		        console.log(res);
		        var base64 = res.Name;
				var words = CryptoJS.enc.Base64.parse(base64);
				var textString = CryptoJS.enc.Utf8.stringify(words);
				this.UName = textString;

				var base64 = res.Email;
				var words = CryptoJS.enc.Base64.parse(base64);
				var textString = CryptoJS.enc.Utf8.stringify(words);
				this.UEmail = textString;
				console.log(this.UEmail);
		    });
	        this.user2 = this.db.object('/payments/'+this.authState.uid).valueChanges();
	            this.user2.subscribe(res => {
	            if(res){
	            this.payment = res
	            	this.SubsId = this.payment.id;
		            this.CustomerId = this.payment.customer;
		            if(this.payment.status=='active'){
		            	this.nopaymentclass = "greenstore";
		            } else {
		            	this.nopaymentclass = "redstore";	
		            }
	            } else {
	            	this.nopaymentclass = "redstore";
	            }
	            console.log(this.nopaymentclass);
	            //console.log(this.payment[0].plan.nickname);
		    });
            let countoptions=[];
	        this.country = this.db.object('/Countries').valueChanges();
		      this.country.subscribe(res => {
		        this.countrylist = res.Country
		        this.countoptions = this.countrylist.split(',');
		        //console.log(this.countoptions);
		    });
	        
	    } else {
	    	this.router.navigate(['/login']);
	    }
	});
  }

  	isValidFormSubmitted: boolean;
  	qwe:any;
  	valaddrs:any;
  	CusId:any='';
  	error1:any='';
  	ngOnInit() {
  		//console.log(environment.stripeKey);
  		this.valaddrs = 'valiaddrs';
  		this.setingres = '';
  		this.latitude = 0;
    	this.longitude = 0;
    	this.addressinfo = '';
    	this.ValidAddress = 'No';
    	this.Address = '';
    	this.UpdateValidAddress = 'Yes';
  		this.handler = StripeCheckout.configure({
	      key: environment.stripeKey,
	      image: '',
	      locale: 'auto',
	      token: token => {
	      	//console.log(this.couponId);
	      	//console.log(token);
	      	/*this.user2 = this.db.object(`/payments/${this.userId}`).valueChanges();
	            this.user2.subscribe(res => {
	            if(res){
	            	this.payment = res
		            this.CustomerId = this.payment.customer;
	            } else {
	            	this.CustomerId = "";
	            }
	            console.log(this.CustomerId);
		    });*/
	        //console.log(`${this.CustomerId}`);
	      	this.CusId = `${this.CustomerId}`;
	      	//console.log(this.CusId);
	        const user = { id : token.id, text : this.email, plan : this.subyplan, NoStore : this.NumberOfStores, Taxes : this.Taxes1, CouponId : this.couponId, customerid : this.CusId, exp_month : token.card.exp_month, exp_year : token.card.exp_year, cardname : token.card.name, address_city: token.card.address_city, address_country: token.card.address_country, address_line1: token.card.address_line1, address_zip: token.card.address_zip, address_state:token.card.address_state};
	  		const headers = new HttpHeaders()
	          .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/payment`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      const payment = { data }
              console.log(data);
              console.log(data['statusCode']);
              console.log(data['message']);
              //console.log(data.statusCode);
                if(data['statusCode']==null || data['statusCode']=='undefined'  ){
                console.log(data['quantity']);
                //var qwe = data['tax_percent'];
                //console.log(data['plan']['amount']);
                //console.log(`${this.UName}`);
                //console.log(`${this.UEmail}`);
                    var ts = new Date(data['start']* 1000);
                    var PaymentDate = ts.toLocaleString();
                    if(data['tax_percent'] == null || data['tax_percent'] == ''){
                        var amountwithtax = 0;
                        this.qwe = 0;
                    } else {
                        var amountwithtax = (((data['plan']['amount']/100)*(data['quantity']))*data['tax_percent'])/100;
                        this.qwe = data['tax_percent'];
                    }
                    this.tolamont = ((data['plan']['amount']/100)*(data['quantity']))+(this.amountwithtax);
                    //this.db.object(`/payments/${this.userId}`).set({
                    this.db.list(`/payments/${this.userId}`).remove();
                    if(data['discount']){
                        this.db.object(`/payments/${this.userId}`).set({
                            billing: data['billing'],
                            billing_cycle_anchor: data['billing_cycle_anchor'],
                            cancel_at_period_end: data['cancel_at_period_end'],
                            canceled_at: data['canceled_at'],
                            created: data['created'],
                            current_period_end: data['current_period_end'],
                            current_period_start: data['current_period_start'],
                            customer:data['customer'],
                            id:data['id'],
                            quantity: data['quantity'],
                            start: data['start'],
                            status: 'pending',
                            tax_percent: data['tax_percent'],
                            object: data['object'],
                            amount: data['plan']['amount'],
                            planid: data['plan']['id'],
                            subscription_item: data['items']['data'][0]['id'],
                            currency: data['plan']['currency'],
                            nickname:data['plan']['nickname'],
                            product:data['plan']['product'],
                            couponid:data['discount']['coupon']['id'],
                            percent_off:data['discount']['coupon']['percent_off'],
                            eventtype: 'subnow',
                        });
                    } else {
                        this.db.object(`/payments/${this.userId}`).set({
                            billing: data['billing'],
                            billing_cycle_anchor: data['billing_cycle_anchor'],
                            cancel_at_period_end: data['cancel_at_period_end'],
                            canceled_at: data['canceled_at'],
                            created: data['created'],
                            current_period_end: data['current_period_end'],
                            current_period_start: data['current_period_start'],
                            customer:data['customer'],
                            id:data['id'],
                            quantity: data['quantity'],
                            start: data['start'],
                            status: 'pending',
                            tax_percent: data['tax_percent'],
                            object: data['object'],
                            amount: data['plan']['amount'],
                            planid: data['plan']['id'],
                            subscription_item: data['items']['data'][0]['id'],
                            currency: data['plan']['currency'],
                            nickname:data['plan']['nickname'],
                            product:data['plan']['product'],
                            eventtype: 'subnow',
                        });
                    }
                    
                    //this.db.list(`/payments/${this.userId}`).push(data)
                    const user1 = {to:`${this.UEmail}`,Name:`${this.UName}`,TotalStore:data['quantity'],tax_percent:this.qwe,amount:this.tolamont,PlanName:data['plan']['nickname'], PaymentDate:PaymentDate};
                    const headers = new HttpHeaders()
                        .set('Content-Type', 'application/json');
                    this.http.post(`https://nodestripepayment.herokuapp.com/sendemail`, JSON.stringify(user1), {
                        headers: headers
                    })
                    .subscribe(data => {
                        //console.log(data);
                    });
                    //this.router.navigate(['/mysubscriptionsplan']);
                    window.location.href = "https://nodestripepayment.herokuapp.com/mysubscriptionsplan";
                } else {
                    this.error1 = data['message'];
                }
		    });
	      }
	    });

  		this.userForm = this.formBuilder.group({
		//uid: new FormControl(''),
		   StoreName: new FormControl('', Validators.required),
		   email: new FormControl(''),
		   Website: new FormControl(''),
		   PhoneNumber: new FormControl(''),
		   Country: new FormControl('United Kingdom', Validators.required),
		   Address: new FormControl('', Validators.required),
		   AddressLatitude: new FormControl(''),
		   AddressLongitude: new FormControl(''),
		   ValidAddress: new FormControl(''),
		});

	    this.paymentForm =this.formBuilder.group({
			email: new FormControl(''),
		    NumberOfStores: new FormControl(''),
		    taxrate: new FormControl(''),
		    tolamont: new FormControl(''),
		    CouponCode: new FormControl(''),
		    MonthlyPlan: new FormControl(null, Validators.required),
		});  
  	}

  	isFieldValid(field: string) {
	    return !this.userForm.get(field).valid && this.userForm.get(field).touched;
	  }

	displayFieldCss(field: string) {
	    return {
	      'has-error': this.isFieldValid(field),
	      'has-feedback': this.isFieldValid(field)
	    };
	}
	
	redbtnvalue: any;
  	numstrovalue: any;
  	tax: any;
  	amountwithtax: any;
  	tolamont: any;
  	InsertCCode: any;
  	Ccode: any;
  	radioChange(event) {
  		this.redbtnvalue = event.target.defaultValue;
  		console.log(this.redbtnvalue);
  		this.numstrovalue = this.paymentForm.get('NumberOfStores').value;
  		console.log(this.redbtnvalue);
		this.CouponId = 'NoCouponId';
  		if(this.redbtnvalue == 'monthly'){
	    	this.subyplan = `${this.setingres.MonthlySubscriptions.PlanName}`;
	    	this.rate = `${this.setingres.MonthlySubscriptions.PlanRate}`;
	    }
	    if(this.redbtnvalue == 'yearly'){
	    	this.subyplan = `${this.setingres.YearlySubscriptions.PlanName}`;
	    	this.rate = `${this.setingres.YearlySubscriptions.PlanRate}`;
	    }
  		this.tax = this.paymentForm.get('taxrate').value;
  		if(this.tax == 0){
  			this.amountwithtax = 0;	
  		} else {
  			this.amountwithtax = (((this.rate)*(this.numstrovalue))*this.tax)/100;
  		}
		this.tolamont = ((this.rate)*(this.numstrovalue))+(this.amountwithtax);
		console.log(this.amountwithtax);
		console.log(this.tolamont);
	    //console.log(event.target.defaultValue);
	    //console.log(this.paymentForm.get('NumberOfStores').value);
	}
	stripCCode: any;
	CouponDis: any;
	CDiscount: any;
	CouponError: any;
	CouponId: any;
	Coupon(event){
		this.CouponError = "";
		this.InsertCCode = this.paymentForm.get('CouponCode').value;
		this.MonthlyPlan = this.paymentForm.get('MonthlyPlan').value;
		this.numstrovalue = this.paymentForm.get('NumberOfStores').value;
		this.tax = this.paymentForm.get('taxrate').value;
		console.log(this.MonthlyPlan);
		this.CouponId = 'NoCouponId';
		if(this.MonthlyPlan == null || this.MonthlyPlan == ''){
			this.CouponError = "Please select plan.";
		} else {
			if(this.InsertCCode == ''){
				this.CouponError = "Please enter coupon code.";
			} else {
				console.log('coupon');
				this.CouponError = "Please wait...";
				const user = { id : 'test coupon'};
		  		const headers = new HttpHeaders()
		          .set('Content-Type', 'application/json');
			    this.http.post(`https://nodestripepayment.herokuapp.com/couponlist`, JSON.stringify(user), {
			      headers: headers
			    })
			    .subscribe(response => {
			      console.log(response['data']);
			      for (var i = 0; i <= response['data'].length; i++) {
			      		if(this.MonthlyPlan == 'monthly'){
							this.subyplan = `${this.setingres.MonthlySubscriptions.PlanName}`;
					    	this.rate = `${this.setingres.MonthlySubscriptions.PlanRate}`;
					    }
					    if(this.MonthlyPlan == 'yearly'){
					    	this.Ccode = `${this.setingres.YearlySubscriptions.CouponCode}`;
					    	this.subyplan = `${this.setingres.YearlySubscriptions.PlanName}`;
					    }
				  		if(this.tax == 0){
				  			this.amountwithtax = 0;	
				  		} else {
				  			this.amountwithtax = (((this.rate)*(this.numstrovalue))*this.tax)/100;
				  		}
						this.tolamont = ((this.rate)*(this.numstrovalue))+(this.amountwithtax);
			      		if(response['data'][i].id == this.InsertCCode){
			      			console.log(response['data'][i].id);
			      			console.log(response['data'][i].percent_off);
			      			
							this.CouponId = this.InsertCCode;
					    	this.CDiscount = (this.tolamont*(response['data'][i].percent_off))/100;
					    	this.tolamont = (this.tolamont)-(this.CDiscount);
			      			this.CouponError = "";
			      			break;
			      		} else {
			      			this.CouponError = "Coupon Code Does not match.";
			      			this.CouponId = 'NoCouponId';
			      		}
			      }
			    });
			}
		}
		console.log(this.CouponId);
	}
	fielderror:any;
    onFormSubmit() {
	   //this.isValidFormSubmitted = false;
	   console.log(this.userForm.status)
	   if(this.userForm.invalid){
	   		this.validateAllFormFields(this.userForm);
	   		this.error = "Please enter requires fields.";
	   		this.fielderror = "Please enter requires fields.";
	   		this.success = "";
		  //return;	
	   } 	
	   if(this.userForm.valid){
		   this.StoreName = this.userForm.get('StoreName').value;
		   this.email = this.userForm.get('email').value;
		   this.Website = this.userForm.get('Website').value;
		   this.PhoneNumber = this.userForm.get('PhoneNumber').value;
		   this.Country = this.userForm.get('Country').value;
		   this.Address = this.userForm.get('Address').value;
		   this.ValidAddress = this.userForm.get('ValidAddress').value;
		   this.AddressLatitude = this.userForm.get('AddressLatitude').value;
		   this.AddressLongitude = this.userForm.get('AddressLongitude').value;
			var str = this.StoreName;
		    var res = str.split(' ').join('-');
		    var text = "";
	   		var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	 		for (var i = 0; i < 10; i++)
	    	text += possible.charAt(Math.floor(Math.random() * possible.length));
	    	const user = { text : this.Address};
				const headers = new HttpHeaders()
			      .set('Content-Type', 'application/json');
			    this.http.post(`https://nodestripepayment.herokuapp.com/getaddress`, JSON.stringify(user), {
			      headers: headers
			    })
			    .subscribe(data => {
			      const payment = { data }
			      	var contact = JSON.parse(data['text']);
					if(contact['status'] == 'OK'){
						if(this.ValidAddress != 'No'){
							this.db.object(`/store/${this.userId}/`+text).set({
					          	Name: this.StoreName,
					          	Email: this.email,
					          	Website: this.Website,
					          	PhoneNumber: this.PhoneNumber,
					          	Address: this.Address,
					          	Country: this.Country,
					          	StorKey: text,
					          	Latitude:this.AddressLatitude,
					          	Longitude:this.AddressLongitude,
					          	subscriptions: 'inactive',
					          	isdeleted: '',
                                sub:0,  
                                PaymentFail:'No',
					      	});
					      	var StoreLat = parseFloat(this.AddressLatitude);
					      	var StoreLong = parseFloat(this.AddressLongitude);
					      	console.log(StoreLat);
							  console.log(StoreLong);
							//const firebaseRef = firebase.database().ref().child('locations1');
							//this.dbRef = this.db.object('/locations');
    						var firebaseRef = firebase.database().ref(`/locations/`);
							var geoFire = new GeoFire(firebaseRef);
							geoFire.set(text, [StoreLat, StoreLong]).then(function() {
							  	console.log("Provided key has been added to GeoFire");
							}, function(error) {
							  	console.log("Error: " + error);
							});
							// const geoQuery = this.geoFire.query({
							// 	center: [51.294, -0.245],
							// 	radius: 10
							// });
							//this.geo.getLocations(100, [StoreLat, StoreLong])
					      	this.success = "Sotre Created.";
					      	console.log('geofire');
						    this.error = "";
						    this.fielderror="";
						    this.userForm.reset();
							this.router.navigate(['/subscriptions']);
							location.reload();
						} else {
							this.error = "Please validate address";
							this.valaddrs = 'valiaddrs';
						}
					} else {
						this.ValidAddress = 'No';
						this.error = "Please enter valid address";
						this.valaddrs = 'valiaddrs';
					}
				});
		}
	}

	validateAllFormFields(formGroup: FormGroup) {
	    Object.keys(formGroup.controls).forEach(field => {
	      console.log(field);
	      const control = formGroup.get(field);
	      if (control instanceof FormControl) {
	        control.markAsTouched({ onlySelf: true });
	      } else if (control instanceof FormGroup) {
	        this.validateAllFormFields(control);
	      }
	    });
	}

	Name: string;
	UpdateError: string;
    updateprofile( event , StoreName, StorKey, Website, email, Country, PhoneNumber, Address, UpdateValidAddress, AddressLatitude, AddressLongitude) {
    	if(StoreName != null && Country != null && Address != null && StoreName != '' && Country != '' && Address != ''){
    		console.log(Address);
    		this.UpdateError = "Please Wait...";
    		const user = { text : Address};
			const headers = new HttpHeaders()
		      .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/getaddress`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      const payment = { data }
		      	var contact = JSON.parse(data['text']);
				if(contact['status'] == 'OK'){
					this.AddressLongitude = contact['results'][0]['geometry']['location']['lng'];
	  				this.AddressLatitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.addressinfo =  contact['results'][0]['formatted_address'];
					   this.db.object(`/store/${this.userId}/`+StorKey).update({
				          Name: StoreName,
				          Email: email,
				          Website: Website,
				          PhoneNumber: PhoneNumber,
				          Address: this.addressinfo,
				          Country: Country,
				          StorKey: StorKey,
				      	  Latitude: this.AddressLongitude,
				      	  Longitude: this.AddressLatitude,
				      	});

				      	var StoreLat = parseFloat(this.AddressLatitude);
				      	var StoreLong = parseFloat(this.AddressLongitude);
					   	var firebaseRef = firebase.database().ref(`/locations/`);
						var geoFire = new GeoFire(firebaseRef);
						geoFire.set(StorKey, [StoreLat, StoreLong]).then(function() {
						  	console.log("Provided key has been added to GeoFire");
						}, function(error) {
						  	console.log("Error: " + error);
						});
					   this.router.navigate(['/subscriptions']);
					   this.UpdateError = "";
					   this.UpdateValidAddress = "No";
					   location.reload();
				} else {
					this.UpdateValidAddress = "No";
					this.UpdateError = "Please enter valid address";
				}
			});
		} else {
			this.UpdateError = "Please enter all fields";
			this.UpdateValidAddress = "No";
		}
	}
	deletestore( event , StorKey) {
	   	this.db.object(`/store/${this.userId}/`+StorKey).remove();
	   	this.db.object(`/locations/`+StorKey).remove();
	   	this.router.navigate(['/subscriptions']);
	   	location.reload();
	}
	monthlyplanrate: any;
	monthlyplanId: any;
	yearlyplanrate: any;
	yearlyplanId: any;
		
  	total:any;
  	Taxes:any;
  	Taxes1:any;
  	couponId:any;
  	monthlyplan: any;
  	yearlyplan: any;
  	subyplan: any;
  	display='none';
  	tltplan: any;
  	rate: any;
  	paymenFormSubmit() {
  		//this.isValidFormSubmitted = false;
	    if(this.paymentForm.invalid){
		  return;	
	    }
	    //if(this.paymentForm.valid){
		    this.isValidFormSubmitted = true;
		    //this.urid = this.paymentForm.get('urid').value;
		    this.email = this.paymentForm.get('email').value;

		    this.NumberOfStores = this.paymentForm.get('NumberOfStores').value;
		    this.MonthlyPlan = this.paymentForm.get('MonthlyPlan').value;
		    this.tolamont = this.paymentForm.get('tolamont').value;
		    this.tltplan = (this.tolamont)*100;

		    this.Taxes1 = `${this.taxrate}`;
		    this.couponId = this.CouponId;
		    this.handler.open({
		      	name: 'Workbudi - Stripe',
		      	email:`${this.authState.email}`,
		      	image: '/assets/wb-logo.png',
		      	excerpt: 'Deposit Funds to Account',
		      	amount: this.tltplan,
		      	currency: 'GBP',
		      	address : true,
		      	label: 'Subscribe and Pay with Card',
		      	local: 'auto',
		      	description: 'Annual Or Monthly Subscription Plan',
	    	});
		    this.error1 = "";
		//}
  	}
  	@HostListener('window:popstate')
	onPopstate() {
	  this.handler.close()
	}
    googleMap(){
    	this.error = "";
    	this.Address = this.userForm.get('Address').value;
    	this.addressinfo = '';
    	console.log(this.Address);
    	if(this.Address != null && this.Address != ''){
	    	console.log(this.Address);
	    	this.error = "Please wait...";
	    	const user = { text : this.Address};
			const headers = new HttpHeaders()
		      .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/getaddress`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		    	console.log(data);
		      const payment = { data }
		      	var contact = JSON.parse(data['text']);
		      	console.log(contact);
				if(contact['status'] == 'OK'){
					this.valaddrs = 'grenbtn';
					this.ValidAddress = 'Yes';
					this.latitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.longitude = contact['results'][0]['geometry']['location']['lng'];
			    	this.AddressLongitude = contact['results'][0]['geometry']['location']['lng'];
	  				this.AddressLatitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.addressinfo =  contact['results'][0]['formatted_address'];
			    	this.display='block';
					this.Address = contact['results'][0]['formatted_address'];
					this.error = "";
				} else {
					this.error = "Please enter valid address";
					this.valaddrs = 'valiaddrs';
			    }
			});
		} else {
			this.error = "Please enter valid address";
			this.valaddrs = 'valiaddrs';
		}
    }
    UpdategoogleMap(event, Address){
    	this.error = "";
    	this.Address = Address;
    	this.addressinfo = '';
    	if(this.Address != null && this.Address != ''){
	    	console.log(this.Address);
	    	this.UpdateError = "Please wait...";
	    	const user = { text : this.Address};
			const headers = new HttpHeaders()
		      .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/updategetaddress`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      console.log(data);
		      const payment = { data }
		      	var contact = JSON.parse(data['text']);
				if(contact['status'] == 'OK'){
					this.ValidAddress = 'Yes';
					this.latitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.longitude = contact['results'][0]['geometry']['location']['lng'];
			    	this.AddressLongitude = contact['results'][0]['geometry']['location']['lng'];
	  				this.AddressLatitude = contact['results'][0]['geometry']['location']['lat'];
			    	this.addressinfo =  contact['results'][0]['formatted_address'];
			    	this.display='block';
					this.Address = contact['results'][0]['formatted_address'];
					//this.error = "";
					this.UpdateError = "";
				} else {
					this.UpdateError = "Please enter valid address";
			    }
			});
		} else {
			this.UpdateError = "Please enter valid address";
		}
    }
    placeMarker($event){
    	this.latitude = $event.coords.lat;
    	this.longitude = $event.coords.lng;
    	this.AddressLongitude = $event.coords.lng;
  		this.AddressLatitude = $event.coords.lat;
    	const user = { latitude : this.latitude, longitude: this.longitude};
		const headers = new HttpHeaders()
	      .set('Content-Type', 'application/json');
	    this.http.post(`https://nodestripepayment.herokuapp.com/getaddressname`, JSON.stringify(user), {
	      headers: headers
	    })
	    .subscribe(data => {
	      //console.log(data);
	      //console.log(data['status']);
	      	var contact = JSON.parse(data['text']);
	      	//console.log(contact['results']);
	      	this.addressinfo =  contact['results'][0]['formatted_address'];
	      	this.Address = contact['results'][0]['formatted_address'];
	  	});
    	//console.log($event.coords);
   		//console.log($event.coords.lat);
    	//console.log($event.coords.lng);
  	}
    onCloseHandled(){
       this.display='none'; 
    }
  	 ngAfterViewInit() {
	    this.card = elements.create('card', {
		  hidePostalCode: true,
		  allowRememberMe: true,
		  style: {
		    base: {
		      iconColor: '#F99A52',
		      color: '#32315E',
		      lineHeight: '48px',
		      fontWeight: 400,
		      fontFamily: '"Open Sans", "Helvetica Neue", "Helvetica", sans-serif',
		      fontSize: '15px',

		      '::placeholder': {
		        color: '#CFD7DF',
		      }
		    },
		  }
		});
		this.card.mount('#card-info');
	    //this.card.mount(this.cardInfo.nativeElement);

	    //this.card.addEventListener('change', this.cardHandler);
	  }

	  ngOnDestroy() {
	    //this.card.removeEventListener('change', this.cardHandler);
	    this.card.destroy();
	  }

	 /* onChange({ error }) {
	    if (error) {
	      this.error = error.message;
	    } else {
	      this.error = null;
	    }
	    this.cd.detectChanges();
	  }*/

	async onSubmit(form: NgForm) {
	    const { token, error } = await stripe.createToken(this.card);

	    if (error) {
	      	console.log('Something is wrong:', error);
	    } else {
	      	console.log('Success!', token);
	      	const user = { id : token.id, text : this.email, plan : this.subyplan, NoStore : this.NumberOfStores};
	  		const headers = new HttpHeaders()
	          .set('Content-Type', 'application/json');
		    this.http.post(`https://nodestripepayment.herokuapp.com/payment`, JSON.stringify(user), {
		      headers: headers
		    })
		    .subscribe(data => {
		      console.log(data);
		      const payment = { data }
		      	//this.db.object(`/payments/${this.userId}`).set({
		      	this.db.list(`/payments/${this.userId}`).remove();
     			this.db.list(`/payments/${this.userId}`).push(data)
     			//});
     			this.router.navigate(['/mysubscriptionsplan']);
		    });
	    }
	}
  	
  	sendEmail(){
  		const user = {to:'test16.igex@gmail.com',subject:'subject',text:'test message'};
		const headers = new HttpHeaders()
      		.set('Content-Type', 'application/json');
      	this.http.post(`https://nodestripepayment.herokuapp.com/sendemail`, JSON.stringify(user), {
	      	headers: headers
	    })
	    .subscribe(data => {
	    	console.log(data);
	    });
  	}

  	/*getstoredetail(){
		var db1 = firebase.database().ref(`/store/${this.userId}/`);
		let Sub = [];
   		db1.once("value", function(snapshot) {
   			Sub = snapshot.val();
   			var keys = snapshot.key;
   			console.log(keys);
        }, function (errorObject) {
          console.log("The read failed: " + errorObject.code);
        });
  	}*/

}

