

'use strict';

export const MonthlyPlanRate='7.5';
export const YearlyFreeSub='2';
export const YearlyPlanRate='75';
