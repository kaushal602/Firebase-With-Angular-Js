/* SystemJS module definition */
declare var module: {
  id: string;
};

declare var StripeCheckout:any;

declare var stripe: any;
declare var elements: any;